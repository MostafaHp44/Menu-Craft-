const fs = require('fs');
const p = 'frontend/src/templates/site/RestaurantSite.tsx';
const add = `\nimport { guestOrderAPI } from '../../shared/lib/api.service';

function TemplateCheckoutOverlay({ restaurant: r, onClose, onPlaced }: { restaurant: any; onClose: () => void; onPlaced: () => void }) {
  const cart = useCartStore();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [fulfillment, setFulfillment] = useState<'pickup' | 'delivery' | 'table'>('pickup');
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const ordering = (r as any).ordering || {};
  const fulfillmentOpts = ordering.fulfillment || { delivery: true, pickup: true };
  const methods = ordering.paymentMethods ? Object.entries(ordering.paymentMethods)
    .filter(([k, v]: [string, any]) => v && v.enabled)
    .map(([k]: [string]) => ({ code: k, label: k })) : [{ code: 'cash', label: 'Cash' }];

  const submit = async () => {
    setError(null);
    if (!name.trim() || !phone.trim()) { setError('Name and phone required'); return; }
    if (cart.subtotal <= 0) { setError('Cart empty'); return; }
    setSending(true);
    try {
      const payload: any = {
        restaurantId: r.id,
        slug: r.slug,
        customer: { name: name.trim(), phone: phone.trim() },
        fulfillment,
        paymentMethod,
        lines: cart.lines.map((l: any) => ({ itemId: l.itemId, qty: l.qty, options: l.options.map((o: any) => ({ groupId: o.groupId, optionId: o.optionId })) })),
        idempotencyKey: Math.random().toString(36).slice(2),
      };
      const res = await guestOrderAPI.create(payload);
      if (res?.ok && res?.data?.id) {
        onPlaced();
      } else {
        setError('Order failed');
      }
    } catch (e: any) {
      setError(e?.message || 'Order failed');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-sm" role="dialog" aria-modal>
      <button className="absolute inset-0" onClick={onClose} aria-label="close" />
      <div className="relative z-10 w-full max-w-md rounded-t-3xl bg-white p-5 shadow-2xl sm:rounded-3xl sm:p-6">
        <h3 className="text-lg font-bold text-gray-900">Checkout</h3>
        <div className="mt-3 space-y-3">
          <input className="w-full rounded-xl border px-3 py-2 text-sm" placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} />
          <input className="w-full rounded-xl border px-3 py-2 text-sm" placeholder="Phone" value={phone} onChange={(e) => setPhone(e.target.value)} />
          <div className="flex gap-2">{fulfillmentOpts.pickup && <button type="button" onClick={() => setFulfillment('pickup')} className={`rounded-full px-3 py-1 text-xs font-bold ${fulfillment === 'pickup' ? 'bg-primary text-white' : 'bg-gray-100'}`}>Pickup</button>}{fulfillmentOpts.delivery && <button type="button" onClick={() => setFulfillment('delivery')} className={`rounded-full px-3 py-1 text-xs font-bold ${fulfillment === 'delivery' ? 'bg-primary text-white' : 'bg-gray-100'}`}>Delivery</button>}
            <button type="button" onClick={() => setFulfillment('table')} className={`rounded-full px-3 py-1 text-xs font-bold ${fulfillment === 'table' ? 'bg-primary text-white' : 'bg-gray-100'}`}>Dine-in</button></div>
          <div className="flex gap-2 flex-wrap">{methods.map((m) => <button key={m.code} type="button" onClick={() => setPaymentMethod(m.code)} className={`rounded-full px-3 py-1 text-xs font-bold ${paymentMethod === m.code ? 'bg-primary text-white' : 'bg-gray-100'}`}>{m.label}</button>)}</div>
          <button type="button" onClick={submit} disabled={sending} className="w-full rounded-xl bg-primary py-2.5 font-bold text-white">{sending ? 'Placing...' : 'Place Order'}</button>
          {error ? <p className="text-xs text-red-600">{error}</p> : null}
        </div>
      </div>
    </div>
  );
}
`;
fs.appendFileSync(p, add);
console.log('appended OK');
