/* Dev-only: tight-root checks — hero select + URL validation apply. */
const puppeteer = require('puppeteer-core')
const BASE = 'http://localhost:5173'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const PICK_ROOT = `(() => {
  const search = [...document.querySelectorAll('input')].find((i) => /search/i.test(i.placeholder))
  if (!search) return null
  let root = search
  for (let i = 0; i < 8 && root; i++) {
    root = root.parentElement
    if (root && root.querySelectorAll('img[src*="food-"]').length >= 10) return root
  }
  return null
})()`

;(async () => {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
  })
  const page = await browser.newPage()
  const errs = []
  page.on('dialog', (d) => d.accept().catch(() => {}))
  page.on('console', (m) => {
    if (m.type() === 'error') errs.push(m.text().slice(0, 140))
  })
  await page.setViewport({ width: 390, height: 844 })
  const out = {}

  await page.goto(`${BASE}/dashboard/design`, { waitUntil: 'domcontentloaded' })
  await page.evaluate(() => localStorage.setItem('menucraft-lang', 'en'))
  await page.reload({ waitUntil: 'domcontentloaded' })
  await sleep(1800)
  await page.evaluate(() => {
    const b = [...document.querySelectorAll('button')].find((x) => /change hero photo/i.test(x.textContent))
    b && b.click()
  })
  await sleep(600)

  out.rootFound = await page.evaluate(`Boolean(${PICK_ROOT})`)
  out.heroBefore = await page.evaluate(() => {
    const img = [...document.querySelectorAll('img')].find((i) => /hero/i.test(i.alt || ''))
    return img ? img.getAttribute('src') : '?'
  })

  /* click a specific thumb (index 10) inside the tight root */
  out.clickedThumb = await page.evaluate(`(() => {
    const root = ${PICK_ROOT}
    if (!root) return null
    const thumbs = [...root.querySelectorAll('button')].filter((b) => b.querySelector('img[src*="food-"]'))
    const t = thumbs[10]
    if (!t) return null
    const src = t.querySelector('img').getAttribute('src')
    t.click()
    return { src, total: thumbs.length }
  })()`)
  await sleep(700)
  out.heroAfterClick = await page.evaluate(() => {
    const img = [...document.querySelectorAll('img')].find((i) => /hero/i.test(i.alt || ''))
    return img ? img.getAttribute('src') : '?'
  })
  out.pressedInRoot = await page.evaluate(`(() => {
    const root = ${PICK_ROOT}
    if (!root) return []
    return [...root.querySelectorAll('button[aria-pressed=true]')].map(
      (b) => b.querySelector('img')?.getAttribute('src') || b.textContent.trim().slice(0, 15)
    )
  })()`)

  /* URL bad */
  out.badUrl = await page.evaluate(`(() => {
    const root = ${PICK_ROOT}
    if (!root) return null
    const search = [...root.querySelectorAll('input')].find((i) => /search/i.test(i.placeholder))
    const url = [...root.querySelectorAll('input')].find((i) => i !== search)
    if (!url) return 'NO-URL-INPUT'
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set
    setter.call(url, 'banana')
    url.dispatchEvent(new Event('input', { bubbles: true }))
    const apply = [...root.querySelectorAll('button')].find((b) => /^apply$/i.test(b.textContent.trim()))
    if (!apply) return 'NO-APPLY'
    apply.click()
    return 'APPLIED-CLICK'
  })()`)
  await sleep(600)
  out.badUrlError = await page.evaluate(`(() => {
    const root = ${PICK_ROOT}
    if (!root) return null
    const errs = [...root.querySelectorAll('p, span, div')].map((e) => e.textContent.trim())
      .filter((t) => t && t.length < 90 && /valid|link|url|http|banana/i.test(t))
    return errs.slice(0, 3)
  })()`)
  out.heroAfterBad = await page.evaluate(() => {
    const img = [...document.querySelectorAll('img')].find((i) => /hero/i.test(i.alt || ''))
    return img ? img.getAttribute('src') : '?'
  })

  /* URL good */
  out.goodUrl = await page.evaluate(`(() => {
    const root = ${PICK_ROOT}
    if (!root) return null
    const search = [...root.querySelectorAll('input')].find((i) => /search/i.test(i.placeholder))
    const url = [...root.querySelectorAll('input')].find((i) => i !== search)
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set
    setter.call(url, 'https://images.example.com/own.jpg')
    url.dispatchEvent(new Event('input', { bubbles: true }))
    const apply = [...root.querySelectorAll('button')].find((b) => /^apply$/i.test(b.textContent.trim()))
    apply && apply.click()
    return 'CLICKED'
  })()`)
  await sleep(700)
  out.heroAfterGood = await page.evaluate(() => {
    const img = [...document.querySelectorAll('img')].find((i) => /hero/i.test(i.alt || ''))
    return img ? img.getAttribute('src') : '?'
  })

  out.errs = errs
  console.log(JSON.stringify(out, null, 1))
  await browser.close()
})()
