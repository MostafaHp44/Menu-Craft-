/* Dev-only: find what is wider than the 390 viewport on /dashboard/design. */
const puppeteer = require('puppeteer-core')
const BASE = 'http://localhost:5173'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

;(async () => {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
  })
  const page = await browser.newPage()
  await page.setViewport({ width: 390, height: 844 })
  await page.goto(`${BASE}/dashboard/design`, { waitUntil: 'domcontentloaded' })
  await page.evaluate(() => localStorage.setItem('menucraft-lang', 'en'))
  await page.reload({ waitUntil: 'domcontentloaded' })
  await sleep(1800)

  const out = await page.evaluate(() => {
    const wide = [...document.querySelectorAll('*')]
      .map((e) => ({
        t: e.tagName,
        c: (typeof e.className === 'string' ? e.className : '').slice(0, 70),
        ow: e.offsetWidth,
        sw: e.scrollWidth,
        txt: (e.textContent || '').trim().slice(0, 40),
      }))
      .filter((x) => x.ow > 420 || x.sw > 420)
      .slice(0, 25)
    return {
      docScroll: document.documentElement.scrollWidth,
      bodyScroll: document.body.scrollWidth,
      wide,
    }
  })
  console.log(JSON.stringify(out, null, 1))
  await browser.close()
})()
