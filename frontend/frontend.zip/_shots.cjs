/* Screenshot + audit sweep.  node _shots.cjs [lang] [width] [route ...] */
const puppeteer = require('puppeteer-core')
const fs = require('fs')
const path = require('path')

const OUT = path.join(process.env.TEMP || 'C:\\Windows\\Temp', 'menucraft-shots')
const BASE = 'http://localhost:5173'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const lang = process.argv[2] || 'en'
const width = Number(process.argv[3] || 1440)
const routes =
  process.argv.length > 4
    ? process.argv.slice(4)
    : ['/', '/templates', '/signin', '/dashboard', '/dashboard/editor', '/admin', '/menu-demo']

;(async () => {
  fs.mkdirSync(OUT, { recursive: true })
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
    args: ['--no-sandbox', '--disable-dev-shm-usage', '--hide-scrollbars'],
  })

  const results = []
  for (const route of routes) {
    const page = await browser.newPage()
    await page.setViewport({ width, height: width < 500 ? 844 : 900 })
    await page.evaluateOnNewDocument((l) => {
      try {
        localStorage.setItem('menucraft-lang', l)
      } catch (e) {
        void e
      }
    }, lang)
    const errors = []
    page.on('console', (m) => m.type() === 'error' && errors.push(m.text()))
    page.on('pageerror', (e) => errors.push(String(e)))
    await page.goto(BASE + route, { waitUntil: 'networkidle0' })
    await sleep(700)

    const info = await page.evaluate(() => ({
      dir: document.documentElement.dir,
      lang: document.documentElement.lang,
      scrollW: document.documentElement.scrollWidth,
      vw: window.innerWidth,
      broken: Array.from(document.images).filter((i) => i.complete && i.naturalWidth === 0).length,
      text: (document.body.innerText || '').slice(0, 0),
    }))

    const slug = route === '/' ? 'home' : route.replace(/\//g, '-').replace(/^-/, '')
    const file = path.join(OUT, `${lang}-${width}-${slug}.png`)
    await page.screenshot({ path: file })
    const overflow = info.scrollW > info.vw
    results.push({ route, ...info, overflow, errors: errors.length, file })
    console.log(
      `${route.padEnd(24)} dir=${info.dir} scroll=${info.scrollW}/${info.vw}` +
        `${overflow ? ' OVERFLOW' : ''} broken=${info.broken} errors=${errors.length}`
    )
    errors.slice(0, 3).forEach((e) => console.log('   ! ' + e))
    await page.close()
  }

  await browser.close()
  fs.writeFileSync(path.join(OUT, `audit-${lang}-${width}.json`), JSON.stringify(results, null, 2))
  const bad = results.filter((r) => r.overflow || r.errors || r.broken)
  console.log(bad.length ? `\n${bad.length} route(s) need attention` : '\nall clean')
})()
