/* Dev-only: visual check of the open hero picker selection state. */
const puppeteer = require('puppeteer-core')
const BASE = 'http://localhost:5173'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

;(async () => {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
  })
  const page = await browser.newPage()
  const errs = []
  page.on('dialog', (d) => d.accept().catch(() => {}))
  page.on('console', (m) => {
    if (m.type() === 'error') errs.push(m.text().slice(0, 100))
  })
  await page.setViewport({ width: 390, height: 900, deviceScaleFactor: 2 })
  await page.goto(`${BASE}/dashboard/design`, { waitUntil: 'domcontentloaded' })
  await page.evaluate(() => localStorage.setItem('menucraft-lang', 'en'))
  await page.reload({ waitUntil: 'domcontentloaded' })
  await sleep(1800)

  await page.evaluate(() => {
    const b = [...document.querySelectorAll('button')].find((x) => /change hero photo/i.test(x.textContent))
    b && b.click()
  })
  await sleep(700)
  await page.evaluate(() => {
    const search = [...document.querySelectorAll('input')].find((i) => /search/i.test(i.placeholder))
    let root = search
    for (let i = 0; i < 8 && root; i++) {
      root = root.parentElement
      if (root && root.querySelectorAll('img[src*="food-"]').length >= 10) break
    }
    const thumbs = [...root.querySelectorAll('button')].filter((b) => b.querySelector('img[src*="food-"]'))
    thumbs[10] && thumbs[10].click()
  })
  await sleep(700)

  const state = await page.evaluate(() => {
    const search = [...document.querySelectorAll('input')].find((i) => /search/i.test(i.placeholder))
    let root = search
    for (let i = 0; i < 8 && root; i++) {
      root = root.parentElement
      if (root && root.querySelectorAll('img[src*="food-"]').length >= 10) break
    }
    const pressed = [...root.querySelectorAll('button[aria-pressed=true]')].map(
      (b) => b.querySelector('img')?.getAttribute('src') || 'chip:' + b.textContent.trim().slice(0, 12)
    )
    /* scroll picker into view for the shot */
    root.scrollIntoView({ block: 'center' })
    return { pressed, thumbs: root.querySelectorAll('img[src*="food-"]').length }
  })
  await sleep(500)
  const dir = process.env.TEMP || '.'
  await page.screenshot({ path: `${dir}\\menucraft-shots\\check-hero-picker.png` })
  console.log(JSON.stringify({ state, errs }, null, 1))
  await browser.close()
})()
