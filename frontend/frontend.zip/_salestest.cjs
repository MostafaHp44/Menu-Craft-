/* Dev-only: sales-detail + social-links E2E checks. */
const puppeteer = require('puppeteer-core')
const BASE = 'http://localhost:5173'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

async function clickByText(page, re, scope = 'button, a, [role=button]') {
  return page.evaluate(
    (rx, sel) => {
      const pattern = new RegExp(rx, 'i')
      const el = [...document.querySelectorAll(sel)].find((e) =>
        pattern.test((e.textContent || e.getAttribute('aria-label') || '').trim())
      )
      if (el) {
        el.click()
        return (el.textContent || '').trim().slice(0, 40)
      }
      return null
    },
    re,
    scope
  )
}

;(async () => {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
  })
  const page = await browser.newPage()
  const errs = []
  page.on('dialog', (d) => d.accept().catch(() => {}))
  page.on('console', (m) => {
    if (m.type() === 'error') errs.push(m.text().slice(0, 130))
  })
  await page.setViewport({ width: 1440, height: 1000 })
  const out = {}

  /* ================= A. ADMIN SALES ================= */
  await page.goto(`${BASE}/admin`, { waitUntil: 'domcontentloaded' })
  await page.evaluate(() => localStorage.setItem('menucraft-lang', 'en'))
  await page.reload({ waitUntil: 'domcontentloaded' })
  await sleep(1400)
  await clickByText(page, 'super admin')
  await sleep(1200)
  await clickByText(page, '^Sales$')
  await sleep(1400)

  out.sales = await page.evaluate(() => {
    const headings = [...document.querySelectorAll('main h2, main h3, main h4')].map((h) =>
      h.textContent.trim().slice(0, 50)
    )
    const tables = [...document.querySelectorAll('main table')].map((t) => {
      const heads = [...t.querySelectorAll('thead th')].map((th) => th.textContent.trim())
      const rows = [...t.querySelectorAll('tbody tr')].slice(0, 3).map((tr) =>
        [...tr.querySelectorAll('td')].map((td) => td.textContent.replace(/\s+/g, ' ').trim().slice(0, 26))
      )
      return { heads, rowCount: t.querySelectorAll('tbody tr').length, rows }
    })
    const hhmm = [...document.querySelectorAll('main td')].map((td) => td.textContent.trim()).filter((t) => /^\d{2}:\d{2}$/.test(t))
    const simulated = [...document.querySelectorAll('main *')].filter((e) => e.children.length === 0 && /^simulated$/i.test(e.textContent.trim())).length
    const moneyCells = [...document.querySelectorAll('main td')].map(td => td.textContent.trim()).filter(t => /^\$/.test(t)).slice(0, 8)
    return { headings, tables: tables.map((t) => ({ ...t, rows: t.rows.slice(0, 2) })), hhmmSample: hhmm.slice(0, 6), hhmmCount: hhmm.length, simulatedBadges: simulated, moneyCells }
  })

  /* switch client -> data must change */
  out.clientSwitch = await page.evaluate(() => {
    const sel = [...document.querySelectorAll('select')].find((s) =>
      [...s.options].some((o) => /Bella/i.test(o.textContent))
    )
    if (!sel) return null
    const before = document.body.textContent.slice(0, 0) // noop
    const other = [...sel.options].find((o) => !o.selected && o.value)
    const otherName = other ? other.textContent : null
    if (other) {
      const setter = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value').set
      setter.call(sel, other.value)
      sel.dispatchEvent(new Event('change', { bubbles: true }))
    }
    return otherName
  })
  await sleep(900)
  out.afterSwitch = await page.evaluate(() => {
    const h = [...document.querySelectorAll('main h2, main h3')].map((x) => x.textContent.trim())
    return h.filter((t) => /report|dishes|first|top/i.test(t)).slice(0, 4)
  })

  /* mobile: cards, no overflow */
  await page.setViewport({ width: 390, height: 844 })
  await sleep(800)
  out.mobile = await page.evaluate(() => ({
    scroll: document.documentElement.scrollWidth,
    tablesVisible: [...document.querySelectorAll('main table')].filter((t) => t.getBoundingClientRect().height > 0).length,
    cards: [...document.querySelectorAll('main *')].filter((e) => /\d{2}:\d{2}/.test(e.textContent) && e.querySelector && [...e.querySelectorAll('*')].length < 40 && e.getBoundingClientRect().height > 30).length,
  }))
  await page.screenshot({ path: `${process.env.TEMP}\\menucraft-shots\\admin-sales-mobile.png` })
  await page.setViewport({ width: 1440, height: 1000 })
  await sleep(700)
  await page.screenshot({ path: `${process.env.TEMP}\\menucraft-shots\\admin-sales-desktop.png`, fullPage: true })

  /* ================= B. SOCIALS: design inputs -> footer href ================= */
  await page.goto(`${BASE}/dashboard/design`, { waitUntil: 'domcontentloaded' })
  await sleep(1600)
  out.designInputs = await page.evaluate(() => {
    const labels = [...document.querySelectorAll('label, p, h3, h4, legend, span')]
      .map((e) => e.textContent.trim())
      .filter((t) => /^(Instagram|Facebook|Website)$/i.test(t))
    const socialInput = (name) => {
      const lab = [...document.querySelectorAll('label, span, p, div')].find(
        (e) => e.textContent.trim() === name && e.querySelector && e.querySelector('input')
      )
      const input = lab ? lab.querySelector('input') : [...document.querySelectorAll('input')].find((i) =>
        new RegExp(name, 'i').test((i.getAttribute('aria-label') || '') + i.placeholder)
      )
      return input || null
    }
    const ig = socialInput('Instagram')
    if (ig) {
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set
      setter.call(ig, 'testhandle')
      ig.dispatchEvent(new Event('input', { bubbles: true }))
    }
    return { labelsFound: labels.slice(0, 6), igSet: Boolean(ig) }
  })
  await sleep(800)
  out.footerHref = await page.evaluate(() => {
    const a = [...document.querySelectorAll('a[href*="instagram"]')].find((x) => x.href.includes('instagram.com'))
    return a ? a.getAttribute('href') : null
  })

  /* ================= C. EDITOR: tap footer handle ================= */
  await page.goto(`${BASE}/dashboard/editor`, { waitUntil: 'domcontentloaded' })
  await sleep(1800)
  await page.evaluate(() => {
    const b = [...document.querySelectorAll('button')].find((x) => x.textContent.trim() === 'Preview')
    b && b.click()
  })
  await sleep(900)
  out.handleTap = await page.evaluate(() => {
    const h = [...document.querySelectorAll('.rs-socials__handle, .rs-socials span')].find((e) => {
      const r = e.getBoundingClientRect()
      return r.width > 0 && r.height > 0
    })
    if (!h) return null
    const r = h.getBoundingClientRect()
    return { x: r.x + r.width / 2, y: r.y + r.height / 2, text: h.textContent.trim().slice(0, 24) }
  })
  if (out.handleTap) {
    await page.mouse.click(out.handleTap.x, out.handleTap.y)
    await sleep(700)
    out.toolbarLabel = await page.evaluate(() => {
      const t = [...document.querySelectorAll('button, span, div')]
        .map((e) => e.textContent.trim())
        .find((x) => /^(Instagram|Facebook|Website)$/.test(x))
      return t || null
    })
    out.stillInEditor = await page.evaluate(() => location.pathname)
  }

  /* ================= D. PUBLISHED MENUDEMO: real links ================= */
  await page.goto(`${BASE}/menu-demo`, { waitUntil: 'domcontentloaded' })
  await sleep(1500)
  out.publishedLinks = await page.evaluate(() => {
    const links = [...document.querySelectorAll('.rs-socials a')].map((a) => ({
      href: a.getAttribute('href'),
      target: a.getAttribute('target'),
      handle: a.textContent.trim().slice(0, 20),
    }))
    return links
  })

  out.errs = errs
  console.log(JSON.stringify(out, null, 1))
  await browser.close()
})()
