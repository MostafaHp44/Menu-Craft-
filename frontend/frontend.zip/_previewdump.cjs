/* Dev-only: dump the design preview card children widths + screenshot. */
const puppeteer = require('puppeteer-core')
const BASE = 'http://localhost:5173'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

;(async () => {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
  })
  const page = await browser.newPage()
  await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2 })
  await page.goto(`${BASE}/dashboard/design`, { waitUntil: 'domcontentloaded' })
  await page.evaluate(() => localStorage.setItem('menucraft-lang', 'en'))
  await page.reload({ waitUntil: 'domcontentloaded' })
  await sleep(1800)

  const dump = await page.evaluate(() => {
    const node = [...document.querySelectorAll('div')].find(
      (d) => typeof d.className === 'string' && d.className.includes('lg:col-start-2 lg:row-start-1')
    )
    if (!node) return null
    const walk = (el, depth) => {
      const r = el.getBoundingClientRect()
      const item = {
        d: depth,
        t: el.tagName,
        c: (typeof el.className === 'string' ? el.className : '').slice(0, 55),
        w: Math.round(r.width),
        x: Math.round(r.x),
      }
      const kids = depth < 3 ? [...el.children].map((k) => walk(k, depth + 1)) : []
      return { ...item, kids }
    }
    return walk(node, 0)
  })
  console.log(JSON.stringify(dump, null, 1))

  await page.screenshot({ path: `${process.env.TEMP}\\menucraft-shots\\check-design-overflow.png` })
  await browser.close()
})()
