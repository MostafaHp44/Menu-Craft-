/* Dev-only: trace ancestor chains to the first width-jump on design page. */
const puppeteer = require('puppeteer-core')
const BASE = 'http://localhost:5173'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

;(async () => {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
  })
  const page = await browser.newPage()
  await page.setViewport({ width: 390, height: 844 })
  await page.goto(`${BASE}/dashboard/design`, { waitUntil: 'domcontentloaded' })
  await page.evaluate(() => localStorage.setItem('menucraft-lang', 'en'))
  await page.reload({ waitUntil: 'domcontentloaded' })
  await sleep(1800)

  const out = await page.evaluate(() => {
    const w = (e) => Math.round(e.getBoundingClientRect().width)
    const cls = (e) => (typeof e.className === 'string' ? e.className : e.tagName).slice(0, 58)

    /* A. gallery search input -> ancestors */
    const searches = [...document.querySelectorAll('input')].filter((i) => /search/i.test(i.placeholder || ''))
    const chain = []
    let n = searches[0]
    while (n && n !== document.body && chain.length < 14) {
      chain.push({ w: w(n), c: cls(n) })
      n = n.parentElement
    }

    /* B. inside the phone shell: first elements wider than 400 */
    const shell = [...document.querySelectorAll('div')].find(
      (d) => typeof d.className === 'string' && /max-w-\[300px\]/.test(d.className)
    )
    const wideSite = []
    if (shell) {
      const walk = (el, depth) => {
        if (depth > 6 || wideSite.length > 12) return
        if (w(el) > 400) {
          wideSite.push({ d: depth, w: w(el), c: cls(el), txt: (el.textContent || '').trim().slice(0, 30) })
          ;[...el.children].forEach((k) => walk(k, depth + 1))
        }
      }
      ;[...shell.children].forEach((k) => walk(k, 1))
      wideSite.unshift({ d: 0, w: w(shell), c: 'SHELL', txt: '' })
    }
    return { searches: searches.length, chain, shellFound: Boolean(shell), wideSite }
  })
  console.log(JSON.stringify(out, null, 1))
  await browser.close()
})()
