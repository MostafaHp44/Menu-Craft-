/* Dev-only: verify the super-admin Home tab renders with data. */
const puppeteer = require('puppeteer-core')

;(async () => {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
  })
  const page = await browser.newPage()
  const errs = []
  page.on('console', (m) => {
    if (m.type() === 'error') errs.push(m.text().slice(0, 140))
  })
  await page.setViewport({ width: 1440, height: 900 })
  await page.goto('http://localhost:5173/admin?tab=home', { waitUntil: 'networkidle0' })
  await new Promise((r) => setTimeout(r, 600))

  // sign in as super admin through the gate prompt
  const clicked = await page.evaluate(() => {
    const b = [...document.querySelectorAll('button')].find((x) =>
      /super|sign|admin/i.test(x.textContent)
    )
    if (b) {
      b.click()
      return b.textContent.trim()
    }
    return null
  })
  await new Promise((r) => setTimeout(r, 1200))

  const info = await page.evaluate(() => ({
    path: location.pathname + location.search,
    headings: [...document.querySelectorAll('h2,h3')].map((e) => e.textContent.trim()).slice(0, 5),
    toggles: document.querySelectorAll('input[type=checkbox]').length,
    tabs: [...document.querySelectorAll('[role=tab],button')].map((b) => b.textContent.trim()),
    scroll: document.documentElement.scrollWidth,
  }))

  // mobile pass
  await page.setViewport({ width: 390, height: 844 })
  await new Promise((r) => setTimeout(r, 700))
  const mobile = await page.evaluate(() => ({
    scroll: document.documentElement.scrollWidth,
    vw: document.documentElement.clientWidth,
  }))

  console.log(
    JSON.stringify(
      { clicked, path: info.path, headings: info.headings, toggles: info.toggles, mobile, errs },
      null,
      1
    )
  )
  await browser.close()
})()
