/* Dev-only: deep-probe the editor — contenteditable visibility + real click → toolbar. */
const puppeteer = require('puppeteer-core')
const BASE = 'http://localhost:5173'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

;(async () => {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
  })
  const page = await browser.newPage()
  const errs = []
  page.on('dialog', (d) => d.accept().catch(() => {}))
  page.on('console', (m) => {
    if (m.type() === 'error') errs.push(m.text().slice(0, 120))
  })
  await page.setViewport({ width: 390, height: 844 })
  const out = {}

  await page.goto(`${BASE}/dashboard/editor`, { waitUntil: 'domcontentloaded' })
  await sleep(2000)
  /* on phones the site preview lives behind the "Preview" segmented tab */
  const previewTab = await page.evaluate(() => {
    const b = [...document.querySelectorAll('button')].find((x) => x.textContent.trim() === 'Preview')
    if (!b) return false
    b.click()
    return true
  })
  out.previewTab = previewTab
  await sleep(900)
  out.ce = await page.evaluate(() => {
    const all = [...document.querySelectorAll('[contenteditable]')]
    const visible = all.filter((e) => {
      const r = e.getBoundingClientRect()
      return r.width > 0 && r.height > 0
    })
    return {
      total: all.length,
      visible: visible.length,
      attrValues: [...new Set(all.map((e) => e.getAttribute('contenteditable')))],
      sample: all.slice(0, 3).map((e) => {
        const r = e.getBoundingClientRect()
        return { text: e.textContent.slice(0, 24), w: Math.round(r.width), h: Math.round(r.height), x: Math.round(r.x), y: Math.round(r.y) }
      }),
    }
  })

  /* real mouse click on the first visible editable */
  const box = await page.evaluate(() => {
    const el = [...document.querySelectorAll('[contenteditable]')].find((e) => {
      const r = e.getBoundingClientRect()
      return r.width > 0 && r.height > 0 && r.y > 0 && r.y < window.innerHeight
    })
    if (!el) return null
    const r = el.getBoundingClientRect()
    return { x: r.x + r.width / 2, y: r.y + r.height / 2, text: el.textContent.slice(0, 30) }
  })
  out.clicked = box
  if (box) {
    await page.mouse.click(box.x, box.y)
    await sleep(800)
  }
  out.toolbar = await page.evaluate(() => {
    const texts = [...new Set([...document.querySelectorAll('button')].map((b) => b.textContent.trim()).filter(Boolean))]
    return {
      hasLora: texts.includes('Lora'),
      hasDefault: texts.includes('Default'),
      hasBold: texts.some((t) => /bold/i.test(t)) || Boolean(document.querySelector('button[aria-label*=bold i]')),
      sizeBtns: Boolean(document.querySelector('[aria-label*="smaller"], [aria-label*="larger"]')),
      all: texts.filter((t) => t.length < 22).slice(0, 40),
    }
  })

  out.errs = errs
  console.log(JSON.stringify(out, null, 1))
  await browser.close()
})()
