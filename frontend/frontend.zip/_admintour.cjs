﻿const puppeteer = require('puppeteer-core')
const BASE = 'http://localhost:5173'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
;(async () => {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
  })
  const page = await browser.newPage()
  const errs = []
  page.on('console', (m) => { if (m.type() === 'error') errs.push(m.text().slice(0, 100)) })
  await page.setViewport({ width: 1440, height: 900, deviceScaleFactor: 1.5 })
  await page.goto(`${BASE}/admin`, { waitUntil: 'domcontentloaded' })
  await page.evaluate(() => localStorage.setItem('menucraft-lang', 'en'))
  await page.reload({ waitUntil: 'domcontentloaded' })
  await sleep(1400)

  await page.evaluate(() => {
    const b = [...document.querySelectorAll('button')].find((x) => /super admin/i.test(x.textContent))
    b && b.click()
  })
  await sleep(1800)

  const tour = await page.evaluate(() => ({
    path: location.pathname,
    h1: document.querySelector('h1')?.textContent?.slice(0, 70) || null,
    tabs: [...document.querySelectorAll('button, a')].map((b) => b.textContent.trim())
      .filter((t) => /^(Overview|Users|Orders|Templates|Home|Kitchens|Settings|Plans|Subscriptions)$/i.test(t)),
    kpis: [...document.querySelectorAll('main h2, main h3, main [class*=stat], main [class*=card]')]
      .map((e) => e.textContent.replace(/\s+/g, ' ').trim().slice(0, 46))
      .filter((t) => t && /\d/.test(t)).slice(0, 12),
  }))
  await page.screenshot({ path: `${process.env.TEMP}\\menucraft-shots\\admin-desktop.png` })

  /* mobile */
  await page.setViewport({ width: 390, height: 844, deviceScaleFactor: 2 })
  await sleep(900)
  await page.screenshot({ path: `${process.env.TEMP}\\menucraft-shots\\admin-mobile.png` })
  const mobileScroll = await page.evaluate(() => document.documentElement.scrollWidth)
  console.log(JSON.stringify({ tour, mobileScroll, errs }, null, 1))
  await browser.close()
})()
