/* Dev-only: find elements causing horizontal overflow at a given width. */
const puppeteer = require('puppeteer-core')

const CHROME = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe'
const [, , route = '/dashboard/orders', width = '390'] = process.argv

;(async () => {
  const browser = await puppeteer.launch({ executablePath: CHROME, headless: 'new' })
  const page = await browser.newPage()
  await page.setViewport({ width: Number(width), height: 844, deviceScaleFactor: 1 })
  await page.goto(`http://localhost:5173${route}`, { waitUntil: 'networkidle0' })
  await new Promise((r) => setTimeout(r, 800))

  const offenders = await page.evaluate(() => {
    const vw = document.documentElement.clientWidth
    const out = []
    for (const el of document.querySelectorAll('*')) {
      const r = el.getBoundingClientRect()
      if (r.width === 0 || r.height === 0) continue
      if (r.right > vw + 0.5 || r.left < -0.5) {
        out.push({
          tag: el.tagName.toLowerCase(),
          cls: String(el.className).slice(0, 110),
          left: Math.round(r.left),
          right: Math.round(r.right),
          w: Math.round(r.width),
        })
      }
    }
    return { vw, scroll: document.documentElement.scrollWidth, offenders: out.slice(0, 25) }
  })

  console.log(JSON.stringify(offenders, null, 2))
  await browser.close()
})()
