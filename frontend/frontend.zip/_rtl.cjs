/* Physical -> logical Tailwind utilities so the same markup works in LTR (en) and RTL (ar/ku).
   In LTR every logical utility behaves exactly like its physical twin, so English is unchanged. */
const fs = require('fs')
const path = require('path')

const ROOT = path.join(__dirname, 'src')
const files = []
;(function walk(dir) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, e.name)
    if (e.isDirectory()) walk(full)
    else if (/\.(tsx?|css)$/.test(e.name)) files.push(full)
  }
})(ROOT)

function fixBase(b) {
  let out = b
  out = out.replace(/^(-?)ml-/, '$1ms-')
  out = out.replace(/^(-?)mr-/, '$1me-')
  out = out.replace(/^(-?)pl-/, '$1ps-')
  out = out.replace(/^(-?)pr-/, '$1pe-')
  out = out.replace(/^(-?)scroll-ml-/, '$1scroll-ms-')
  out = out.replace(/^(-?)scroll-mr-/, '$1scroll-me-')
  out = out.replace(/^(-?)left-/, '$1start-')
  out = out.replace(/^(-?)right-/, '$1end-')
  if (out === 'text-left') out = 'text-start'
  else if (out === 'text-right') out = 'text-end'
  out = out.replace(/^border-l(?=(-|$))/, 'border-s')
  out = out.replace(/^border-r(?=(-|$))/, 'border-e')
  out = out.replace(/^rounded-tl(?=(-|$))/, 'rounded-ss')
  out = out.replace(/^rounded-tr(?=(-|$))/, 'rounded-se')
  out = out.replace(/^rounded-bl(?=(-|$))/, 'rounded-bs')
  out = out.replace(/^rounded-br(?=(-|$))/, 'rounded-be')
  out = out.replace(/^rounded-l(?=(-|$))/, 'rounded-s')
  out = out.replace(/^rounded-r(?=(-|$))/, 'rounded-e')
  out = out.replace(/^scroll-pl-/, 'scroll-ps-')
  out = out.replace(/^scroll-pr-/, 'scroll-pe-')
  return out
}

const counts = {}
const notes = []
let edited = 0

for (const file of files) {
  const isCss = file.endsWith('.css')
  const before = fs.readFileSync(file, 'utf8')
  let changes = 0

  let after = before.replace(/[^\s"'`,()]+/g, (token) => {
    const m = token.match(/^((?:[\w[\]%./-]+:)*)(.*)$/)
    if (!m) return token
    const [, prefix, base] = m
    if (!base) return token

    if (!isCss) {
      const fixed = fixBase(base)
      if (fixed !== base) {
        changes++
        const key = `${base} -> ${fixed}`.split(' -> ')[0]
        counts[key] = (counts[key] || 0) + 1
        return prefix + fixed
      }
    } else {
      // css: physical position properties -> logical ones
      const fixed = base
        .replace(/^left:/, 'inset-inline-start:')
        .replace(/^right:/, 'inset-inline-end:')
      if (fixed !== base) {
        changes++
        counts[base] = (counts[base] || 0) + 1
        return prefix + fixed
      }
    }
    return token
  })

  if (isCss) {
    // property: value form  (  left: 0; )
    after = after.replace(/(?<![\w-])left\s*:/g, (m) => {
      changes++
      counts['css left:'] = (counts['css left:'] || 0) + 1
      return 'inset-inline-start:'
    })
    after = after.replace(/(?<![\w-])right\s*:/g, (m) => {
      changes++
      counts['css right:'] = (counts['css right:'] || 0) + 1
      return 'inset-inline-end:'
    })
  }

  if (after !== before) {
    fs.writeFileSync(file, after)
    edited++
  }

  // report things that need a human decision
  const rel = path.relative(__dirname, file)
  for (const pattern of [/translate-x-1\/2/g, /(^|\s)divide-x/g, /(^|\s)space-x-/g, /style=\{\{\s*left/g, /style=\{\{\s*right/g]) {
    const hits = (before.match(pattern) || []).length
    if (hits) notes.push(`${rel}: ${pattern} x${hits}`)
  }
}

console.log('files edited:', edited)
console.log('\nutility replacements:')
for (const [k, v] of Object.entries(counts).sort((a, b) => b[1] - a[1])) console.log(`  ${k} x${v}`)
if (notes.length) {
  console.log('\nneeds a manual RTL decision:')
  console.log('  ' + notes.join('\n  '))
}
