/* Dev-only: ImagePicker journeys — search, categories, selection, URL, empty state. */
const puppeteer = require('puppeteer-core')
const BASE = 'http://localhost:5173'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

async function clickByText(page, re, scope = 'button, a, [role=button]') {
  return page.evaluate(
    (rx, sel) => {
      const pattern = new RegExp(rx, 'i')
      const el = [...document.querySelectorAll(sel)].find((e) =>
        pattern.test((e.textContent || e.getAttribute('aria-label') || '').trim())
      )
      if (el) {
        el.click()
        return (el.textContent || '').trim().slice(0, 40)
      }
      return null
    },
    re,
    scope
  )
}

async function fill(page, selector, value) {
  await page.evaluate(
    (sel, val) => {
      const input = document.querySelector(sel)
      if (!input) return
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set
      setter.call(input, val)
      input.dispatchEvent(new Event('input', { bubbles: true }))
    },
    selector,
    value
  )
}

;(async () => {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
  })
  const page = await browser.newPage()
  const errs = []
  page.on('dialog', (d) => d.accept().catch(() => {}))
  page.on('console', (m) => {
    if (m.type() === 'error') errs.push(m.text().slice(0, 140))
  })
  await page.setViewport({ width: 390, height: 844 })
  const out = {}

  /* ---------- A. Design page: hero picker (search + chips + select) ---------- */
  await page.goto(`${BASE}/dashboard/design`, { waitUntil: 'domcontentloaded' })
  await page.evaluate(() => localStorage.setItem('menucraft-lang', 'en'))
  await page.reload({ waitUntil: 'domcontentloaded' })
  await sleep(1800)
  out.openHero = await clickByText(page, 'change hero photo')
  await sleep(600)
  out.heroPicker = await page.evaluate(() => {
    const inputs = [...document.querySelectorAll('input[type=text], input:not([type])')]
    const search = inputs.find((i) => /search/i.test(i.placeholder))
    const chips = [...document.querySelectorAll('button')].map((b) => b.textContent.trim())
    return {
      searchFound: Boolean(search),
      hasAll: chips.includes('All'),
      chipSample: chips.filter((t) =>
        ['Pizza', 'Pasta', 'Dessert', 'Interior', 'Coffee', 'Breakfast'].includes(t)
      ),
      thumbs: document.querySelectorAll('img[src*="food-"]').length,
    }
  })
  /* search filter */
  await fill(page, 'input[placeholder*="earch"]', 'zzz')
  await sleep(400)
  out.emptyState = await page.evaluate(() => document.body.textContent.match(/no images match/i)?.[0] ?? null)
  out.thumbsAfterEmpty = await page.evaluate(
    () => document.querySelectorAll('img[src*="food-"]').length
  )
  await fill(page, 'input[placeholder*="earch"]', 'pizza')
  await sleep(400)
  out.thumbsAfterSearch = await page.evaluate(
    () => document.querySelectorAll('img[src*="food-"]').length
  )
  /* clear + category chip */
  await clickByText(page, '^clear$')
  await sleep(300)
  out.pastaChip = await clickByText(page, '^Pasta$')
  await sleep(400)
  out.thumbsAfterChip = await page.evaluate(
    () => document.querySelectorAll('img[src*="food-"]').length
  )
  /* select an image -> hero changes */
  const beforeHero = await page.evaluate(
    () => document.querySelector('img[alt*="ero" i], img[src*="food-"]')?.getAttribute('src') ?? '?'
  )
  out.heroBefore = beforeHero
  await page.evaluate(() => {
    const imgs = [...document.querySelectorAll('img[src*="food-"]')]
    const target = imgs.find((i) => i.getBoundingClientRect().height > 0)
    target && target.closest('button')?.click()
  })
  await sleep(600)
  out.heroAfterSelect = await page.evaluate(() => {
    const btns = [...document.querySelectorAll('button')]
    const checked = btns.find((b) => b.getAttribute('aria-pressed') === 'true' && b.querySelector('img[src*="food-"]'))
    return checked ? checked.querySelector('img').getAttribute('src') : null
  })

  /* ---------- B. URL input: bad + good ---------- */
  await fill(page, 'input[placeholder*="ttp"]', 'not-a-url')
  await page.keyboard.press('Enter')
  await sleep(400)
  out.urlBadError = await page.evaluate(() =>
    document.body.textContent.match(/enter a valid|invalid|https?/i)?.[0] ?? null
  )
  await fill(page, 'input[placeholder*="ttp"]', 'https://images.example.com/own.jpg')
  await clickByText(page, '^apply$')
  await sleep(500)
  out.urlApplied = await page.evaluate(() => {
    const checked = [...document.querySelectorAll('button[aria-pressed=true]')].find((b) =>
      b.querySelector('img')
    )
    return checked ? checked.querySelector('img').getAttribute('src') : null
  })

  /* ---------- C. Editor image modal ---------- */
  await page.goto(`${BASE}/dashboard/editor`, { waitUntil: 'domcontentloaded' })
  await sleep(1800)
  await page.evaluate(() => {
    const b = [...document.querySelectorAll('button')].find((x) => x.textContent.trim() === 'Preview')
    b && b.click()
  })
  await sleep(900)
  /* tap a gallery/hero image (img inside preview with food src) */
  await page.evaluate(() => {
    const img = [...document.querySelectorAll('img[src*="food-"]')].find((i) => {
      const r = i.getBoundingClientRect()
      return r.width > 0 && r.y > 0 && r.y < window.innerHeight
    })
    if (img) {
      const r = img.getBoundingClientRect()
      img.dispatchEvent(new MouseEvent('click', { bubbles: true }))
      window.__imgXY = { x: r.x + r.width / 2, y: r.y + r.height / 2 }
    }
  })
  const xy = await page.evaluate(() => window.__imgXY || null)
  if (xy) await page.mouse.click(xy.x, xy.y)
  await sleep(800)
  out.modal = await page.evaluate(() => {
    const search = [...document.querySelectorAll('input')].find((i) => /search/i.test(i.placeholder))
    const chips = [...document.querySelectorAll('button')].map((b) => b.textContent.trim())
    return {
      open: Boolean(search),
      hasAll: chips.includes('All'),
      pasta: chips.includes('Pasta'),
      urlRow: Boolean([...document.querySelectorAll('input')].find((i) => /url/i.test(i.placeholder + i.getAttribute('aria-label') + ''))),
    }
  })

  out.errs = errs
  console.log(JSON.stringify(out, null, 1))
  await browser.close()
})()
