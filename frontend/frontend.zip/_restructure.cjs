/* One-shot codemod: reorganise src/ into the requested folder structure
   and rewrite every relative import/export/css-url reference accordingly. */
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, 'src');

/** old (relative to src/) -> new (relative to src/) */
const MOVES = {
  'components/ui.tsx': 'shared/ui/ui.tsx',
  'components/icons.tsx': 'shared/ui/icons.tsx',
  'components/ScaledFrame.tsx': 'shared/ui/ScaledFrame.tsx',
  'components/marketing/MarketingHeader.tsx': 'shared/chrome/MarketingHeader.tsx',
  'components/marketing/MarketingFooter.tsx': 'shared/chrome/MarketingFooter.tsx',
  'components/menu/MenuEditor.tsx': 'features/client/menu/MenuEditor.tsx',
  'components/panels/DesignPanels.tsx': 'features/client/design/DesignPanels.tsx',
  'components/site/RestaurantSite.tsx': 'templates/site/RestaurantSite.tsx',
  'components/site/site.css': 'templates/site/site.css',
  'lib/templates.ts': 'templates/data/templates.ts',
  'lib/palettes.ts': 'templates/data/palettes.ts',
  'lib/fonts.ts': 'templates/data/fonts.ts',
  'lib/demoData.ts': 'shared/lib/demoData.ts',
  'lib/hooks.ts': 'shared/lib/hooks.ts',
  'lib/images.ts': 'shared/lib/images.ts',
  'lib/types.ts': 'shared/lib/types.ts',
  'lib/utils.ts': 'shared/lib/utils.ts',
  'store/useStore.ts': 'shared/store/useStore.ts',
  'pages/dashboard/DashboardLayout.tsx': 'features/client/DashboardLayout.tsx',
  'pages/dashboard/Overview.tsx': 'features/client/Overview.tsx',
  'pages/dashboard/MyMenu.tsx': 'features/client/MyMenu.tsx',
  'pages/dashboard/DesignBranding.tsx': 'features/client/DesignBranding.tsx',
  'pages/dashboard/TemplatesPage.tsx': 'features/client/TemplatesPage.tsx',
  'pages/dashboard/QrCodePage.tsx': 'features/client/QrCodePage.tsx',
  'pages/dashboard/SubscriptionPage.tsx': 'features/client/SubscriptionPage.tsx',
  'pages/dashboard/SettingsPage.tsx': 'features/client/SettingsPage.tsx',
  'pages/Admin.tsx': 'features/admin/Admin.tsx',
  'pages/SignIn.tsx': 'features/auth/SignIn.tsx',
  'pages/Editor.tsx': 'features/client/Editor.tsx',
  'pages/Home.tsx': 'features/marketing/Home.tsx',
  'pages/Templates.tsx': 'features/marketing/Templates.tsx',
  'pages/TemplatePreview.tsx': 'features/marketing/TemplatePreview.tsx',
  'pages/MenuDemo.tsx': 'features/marketing/MenuDemo.tsx',
  'pages/NotFound.tsx': 'features/marketing/NotFound.tsx',
};

const EXTS = ['', '.ts', '.tsx', '.d.ts', '.css', '.js', '.jsx', '/index.ts', '/index.tsx'];

function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, e.name);
    if (e.isDirectory()) walk(full, out);
    else out.push(full);
  }
  return out;
}

const files = walk(ROOT);
const rel = (abs) => path.relative(ROOT, abs).split(path.sep).join('/');

/** absolute-old-path (posix, src relative) -> absolute-new-path */
const map = new Map();
for (const f of files) {
  const r = rel(f);
  map.set(r, MOVES[r] || r);
}

function resolveTarget(fromFile, spec) {
  const base = path.posix.normalize(path.posix.join(path.posix.dirname(fromFile), spec));
  for (const ext of EXTS) if (map.has(base + ext)) return base + ext;
  return null;
}

function emit(fromNew, toNew) {
  let relp = path.posix.relative(path.posix.dirname(fromNew), toNew);
  if (!relp.startsWith('.')) relp = './' + relp;
  return relp;
}

let changed = 0;
const report = [];

for (const f of files) {
  const oldRel = rel(f);
  const newRel = map.get(oldRel);
  let text = fs.readFileSync(f, 'utf8');
  const before = text;

  // 1) `from '...'`, `export ... from '...'`
  text = text.replace(/(from\s*)(['"])(\.\.?\/[^'"]+)\2/g, (m, pre, q, spec) => {
    const t = resolveTarget(oldRel, spec);
    if (!t) return m;
    return `${pre}${q}${emit(newRel, map.get(t))}${q}`;
  });

  // 2) bare `import '...'`  /  `import('...')`
  text = text.replace(/(import\s*\(?\s*)(['"])(\.\.?\/[^'"]+)\2/g, (m, pre, q, spec) => {
    const t = resolveTarget(oldRel, spec);
    if (!t) return m;
    return `${pre}${q}${emit(newRel, map.get(t))}${q}`;
  });

  // 3) css url(...)
  text = text.replace(/url\((['"]?)(\.\.?\/[^'")]+)\1\)/g, (m, q, spec) => {
    const t = resolveTarget(oldRel, spec);
    if (!t) return m;
    return `url(${q}${emit(newRel, map.get(t))}${q})`;
  });

  if (text !== before) {
    report.push(`rewrite ${oldRel}`);
    changed += 1;
  }

  const dest = path.join(ROOT, newRel);
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  if (path.resolve(f) !== path.resolve(dest)) fs.writeFileSync(dest, text);
  else fs.writeFileSync(f, text);
}

// remove old copies that have moved (files were written to new paths only)
for (const [oldR, newR] of map) {
  if (oldR === newR) continue;
  const oldAbs = path.join(ROOT, oldR);
  const newAbs = path.join(ROOT, newR);
  if (fs.existsSync(oldAbs) && path.resolve(oldAbs) !== path.resolve(newAbs)) {
    fs.rmSync(oldAbs, { force: true });
  }
}

// remove now-empty / superseded directories
const gone = [];
for (const dead of ['components', 'lib', 'store', 'pages']) {
  const dir = path.join(ROOT, dead);
  if (!fs.existsSync(dir)) continue;
  const remaining = walk(dir);
  if (remaining.length === 0) {
    fs.rmSync(dir, { recursive: true, force: true });
    gone.push(dead + '/');
  } else {
    report.push(`LEFT BEHIND in ${dead}/: ` + remaining.map(rel).join(', '));
  }
}

console.log(report.join('\n'));
console.log(`\nfiles rewritten: ${changed}`);
if (gone.length) console.log('removed empty dirs: ' + gone.join(', '));
