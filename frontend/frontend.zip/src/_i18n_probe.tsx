import { useT, useI18n } from './shared/i18n'

export function _I18nTypeProbe() {
  const t = useT()
  const { lang, dir } = useI18n()
  const good: string = t('orders.title') + t('admin.salesReport', { client: 'Bella' }) + lang + dir
  t('orders.titlee')
  return good
}
