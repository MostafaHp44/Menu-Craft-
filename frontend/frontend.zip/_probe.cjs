/* Dev-only: probe editor toolbar + signin DOM to fix journey selectors. */
const puppeteer = require('puppeteer-core')
const BASE = 'http://localhost:5173'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

;(async () => {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
  })
  const page = await browser.newPage()
  const errs = []
  page.on('dialog', (d) => d.accept().catch(() => {}))
  page.on('console', (m) => {
    if (m.type() === 'error') errs.push(m.text().slice(0, 120))
  })
  await page.setViewport({ width: 390, height: 844 })
  const out = {}

  /* editor: contenteditable nodes + button inventory */
  await page.goto(`${BASE}/dashboard/editor`, { waitUntil: 'domcontentloaded' })
  await sleep(1800)
  out.editables = await page.evaluate(() => {
    const ce = [...document.querySelectorAll('[contenteditable]')]
    return {
      count: ce.length,
      samples: ce.slice(0, 5).map((e) => ({
        tag: e.tagName,
        ce: e.getAttribute('contenteditable'),
        text: (e.textContent || '').slice(0, 30),
      })),
    }
  })
  /* click the first editable and dump new buttons */
  await page.evaluate(() => {
    const ce = [...document.querySelectorAll('[contenteditable=true], [contenteditable="true"]')].find(
      (e) => e.offsetParent
    )
    ce && ce.click()
  })
  await sleep(700)
  out.afterClick = await page.evaluate(() => {
    const texts = [...new Set([...document.querySelectorAll('button')].map((b) => b.textContent.trim()).filter(Boolean))]
    return texts.filter((t) => t.length < 26)
  })

  /* signin in SIGN-IN mode */
  await page.goto(`${BASE}/signin?mode=signin`, { waitUntil: 'domcontentloaded' })
  await sleep(1200)
  out.signin = await page.evaluate(() => ({
    buttons: [...new Set([...document.querySelectorAll('button, a')].map((b) => b.textContent.trim()).filter((t) => t && t.length < 40))],
    inputs: [...document.querySelectorAll('input')].map((i) => ({ type: i.type, ph: i.placeholder.slice(0, 30) })),
  }))

  out.errs = errs
  console.log(JSON.stringify(out, null, 1))
  await browser.close()
})()
