﻿/* Dev-only: URL apply in real async steps -> hero becomes the URL? */
const puppeteer = require('puppeteer-core')
const BASE = 'http://localhost:5173'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

;(async () => {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
  })
  const page = await browser.newPage()
  const errs = []
  page.on('dialog', (d) => d.accept().catch(() => {}))
  page.on('console', (m) => { if (m.type() === 'error') errs.push(m.text().slice(0, 90)) })
  await page.setViewport({ width: 390, height: 844 })
  await page.goto(`${BASE}/dashboard/design`, { waitUntil: 'domcontentloaded' })
  await page.evaluate(() => localStorage.setItem('menucraft-lang', 'en'))
  await page.reload({ waitUntil: 'domcontentloaded' })
  await sleep(1800)

  await page.evaluate(() => {
    const b = [...document.querySelectorAll('button')].find((x) => /change hero photo/i.test(x.textContent))
    b && b.click()
  })
  await sleep(600)
  const open = await page.evaluate(() =>
    [...document.querySelectorAll('input')].filter((i) => /search/i.test(i.placeholder || '')).length
  )

  /* step 1: type URL (separate protocol call so React state flushes) */
  await page.evaluate(() => {
    const searches = [...document.querySelectorAll('input')].filter((i) => /search/i.test(i.placeholder || ''))
    let root = searches[0]
    for (let i = 0; i < 8 && root; i++) {
      root = root.parentElement
      if (root && root.querySelectorAll('img[src*="food-"]').length >= 10) break
    }
    const url = [...root.querySelectorAll('input')].find((i) => !/search/i.test(i.placeholder || ''))
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set
    setter.call(url, 'https://www.w3.org/Icons/w3c_home')
    url.dispatchEvent(new Event('input', { bubbles: true }))
  })
  await sleep(500)

  /* step 2: click Apply */
  const applied = await page.evaluate(() => {
    const searches = [...document.querySelectorAll('input')].filter((i) => /search/i.test(i.placeholder || ''))
    let root = searches[0]
    for (let i = 0; i < 8 && root; i++) {
      root = root.parentElement
      if (root && root.querySelectorAll('img[src*="food-"]').length >= 10) break
    }
    const apply = [...root.querySelectorAll('button')].find((b) => /^apply$/i.test(b.textContent.trim()))
    if (!apply) return 'NO-APPLY'
    if (apply.disabled) return 'DISABLED'
    apply.click()
    return 'CLICKED'
  })
  await sleep(900)

  const state = await page.evaluate(() => {
    const currentHero = [...document.querySelectorAll('img')].find((i) => /hero/i.test(i.alt || ''))
    const searches = [...document.querySelectorAll('input')].filter((i) => /search/i.test(i.placeholder || ''))
    return {
      searchesAfter: searches.length,
      heroSrc: currentHero ? currentHero.getAttribute('src') : '?',
      heroLoaded: currentHero ? currentHero.naturalWidth > 0 : null,
    }
  })
  console.log(JSON.stringify({ open, applied, state, errs }, null, 1))
  await browser.close()
})()
