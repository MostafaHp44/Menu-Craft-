import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],

  server: {
    port: 5173,
    host: true,
    allowedHosts: ['localhost'],
  },

  build: {
    rollupOptions: {
      output: {
        // لا نعمل manualChunks للـ React
      },
    },
  },
})





























// import { defineConfig } from 'vite'
// import react from '@vitejs/plugin-react'
// import tailwindcss from '@tailwindcss/vite'

// export default defineConfig({
//   plugins: [react(), tailwindcss()],

//   server: {
//     port: 5173,
//     host: true,
//     allowedHosts: [
//       '',
//     ],
//     proxy: {
//       '/api': {
//         target: 'https://api.vertex-electric.org/',
//         changeOrigin: true,
//       },
//       '/uploads': {
//         target: 'https://api.vertex-electric.org/uploads',
//         changeOrigin: true,
//       },
//     },



//     // proxy: {
//     //   '/api': {
//     //     target: 'http://127.0.0.1:3000',
//     //     changeOrigin: true,
//     //   },
//     //   '/uploads': {
//     //     target: 'http://127.0.0.1:3000',
//     //     changeOrigin: true,
//     //   },
//     // },
//   },
// })
