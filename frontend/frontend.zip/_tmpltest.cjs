﻿/* Dev-only: end-to-end — super admin adds a template, visitor sees it. */
const fs = require('fs')
const os = require('os')
const path = require('path')
const puppeteer = require('puppeteer-core')

const DIR = path.join(os.tmpdir(), 'menucraft-shots')
const BASE = 'http://localhost:5173'
const NAME = 'قائمة الصيف' // Arabic name → exercises the unicode slug too

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

;(async () => {
  fs.mkdirSync(DIR, { recursive: true })
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
  })
  const page = await browser.newPage()
  const errs = []
  page.on('dialog', (d) => d.accept().catch(() => {})) // editor's unsaved-changes guard
  page.on('console', (m) => {
    if (m.type() === 'error') errs.push(m.text().slice(0, 140))
  })
  await page.setViewport({ width: 1440, height: 900 })
  const out = {}

  /* 1 — super admin signs in and opens the Templates tab */
  await page.goto(`${BASE}/admin?tab=templates`, { waitUntil: 'domcontentloaded' })
  await sleep(1400)
  await page.evaluate(() => {
    const b = [...document.querySelectorAll('button')].find((x) => /super/i.test(x.textContent))
    b && b.click()
  })
  await sleep(1200)
  out.adminHeading = await page.evaluate(
    () => document.querySelector('h2,h3')?.textContent?.trim() ?? '?'
  )

  /* 2 — open the Add template modal */
  out.modalOpened = await page.evaluate(() => {
    const b = [...document.querySelectorAll('button')].find((x) =>
      /add template/i.test(x.textContent)
    )
    if (!b) return false
    b.click()
    return true
  })
  await sleep(500)

  /* 3 — Arabic name, default base + category, Create */
  out.created = await page.evaluate((name) => {
    const dialog = document.querySelector('[role=dialog]')
    if (!dialog) return false
    const input = dialog.querySelector('input')
    if (!input) return false
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set
    setter.call(input, name)
    input.dispatchEvent(new Event('input', { bubbles: true }))
    const btn = [...dialog.querySelectorAll('button')].find((b) => /create/i.test(b.textContent))
    if (!btn) return false
    btn.click()
    return true
  }, NAME)
  await sleep(900)
  out.adminRowVisible = await page.evaluate(
    (name) => document.body.textContent.includes(name),
    NAME
  )
  await page.screenshot({ path: path.join(DIR, 'x-admin-add-template.png') })

  /* 4 — public gallery now shows it (New badge) */
  await page.goto(`${BASE}/templates`, { waitUntil: 'domcontentloaded' })
  await sleep(800)
  out.gallery = await page.evaluate(() => {
    const cards = [...document.querySelectorAll('article')]
    const customCard = cards.find((c) => c.querySelector('a[href*="/templates/custom-"]'))
    return {
      cards: cards.length,
      hasCustom: Boolean(customCard),
      badge: customCard?.textContent.includes('New') ?? false,
      justAdded: customCard?.textContent.includes('just added') ?? false,
      href: customCard?.querySelector('a[href*="/templates/custom-"]')?.getAttribute('href') ?? null,
    }
  })
  await page.screenshot({ path: path.join(DIR, 'x-gallery-with-custom.png') })

  /* 5 — preview page resolves the custom id (no "Unknown template") */
  await page.goto(`${BASE}${out.gallery.href}`, { waitUntil: 'domcontentloaded' })
  await sleep(900)
  out.preview = await page.evaluate((name) => ({
    unknown: document.body.textContent.includes("Unknown template"),
    showsName: document.body.textContent.includes(name),
  }), NAME)
  await page.screenshot({ path: path.join(DIR, 'x-custom-preview.png') })

  /* 6 — Customize → editor opens with the custom template applied */
  await page.evaluate(() => {
    const b = [...document.querySelectorAll('button')].find((x) =>
      /customize/i.test(x.textContent)
    )
    b && b.click()
  })
  await sleep(1500)
  out.editor = await page.evaluate((name) => ({
    path: location.pathname,
    applied: document.body.textContent.includes(name),
  }), NAME)
  await page.screenshot({ path: path.join(DIR, 'x-editor-custom-applied.png') })

  /* 7 — dashboard template picker */
  await page.goto(`${BASE}/dashboard/templates`, { waitUntil: 'domcontentloaded' })
  await sleep(900)
  out.dashPicker = await page.evaluate(() => ({
    cards: document.querySelectorAll('article').length,
    newText: document.body.textContent.includes('New'),
    path: location.pathname,
  }))

  /* 8 — mobile pass on the public gallery */
  await page.setViewport({ width: 390, height: 844 })
  await page.goto(`${BASE}/templates`, { waitUntil: 'domcontentloaded' })
  await sleep(900)
  out.mobile = await page.evaluate(() => ({
    scroll: document.documentElement.scrollWidth,
    vw: document.documentElement.clientWidth,
  }))
  await page.screenshot({ path: path.join(DIR, 'x-gallery-mobile-390.png'), fullPage: false })

  out.errs = errs
  console.log(JSON.stringify(out, null, 1))
  await browser.close()
})()
