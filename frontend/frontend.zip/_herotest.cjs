/* Dev-only: hero image upload + hero video E2E checks. */
const puppeteer = require('puppeteer-core')
const BASE = 'http://localhost:5173'
const IMG = 'D:\\MBN Group\\Test Menu\\frontend\\public\\images\\food\\food-01.jpg'
const VID = process.env.TEMP + '\\menucraft-hero.mp4'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

async function clickByText(page, re, scope = 'button, a, [role=button], label') {
  return page.evaluate(
    (rx, sel) => {
      const pattern = new RegExp(rx, 'i')
      const el = [...document.querySelectorAll(sel)].find((e) =>
        pattern.test((e.textContent || '').trim())
      )
      if (el) {
        el.click()
        return (el.textContent || '').trim().slice(0, 40)
      }
      return null
    },
    re,
    scope
  )
}

;(async () => {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
  })
  const page = await browser.newPage()
  const errs = []
  page.on('dialog', (d) => d.accept().catch(() => {}))
  page.on('console', (m) => {
    if (m.type() === 'error') errs.push(m.text().slice(0, 140))
  })
  await page.setViewport({ width: 1440, height: 1000 })
  const out = {}

  await page.goto(`${BASE}/dashboard/design`, { waitUntil: 'domcontentloaded' })
  await page.evaluate(() => localStorage.setItem('menucraft-lang', 'en'))
  await page.reload({ waitUntil: 'domcontentloaded' })
  await sleep(1800)

  /* ---------- A. IMAGE UPLOAD via file chooser ---------- */
  out.heroToggle = await clickByText(page, 'change hero photo')
  await sleep(700)
  const [chooserA] = await Promise.all([
    page.waitForFileChooser({ timeout: 8000 }),
    clickByText(page, '^Upload image$'),
  ])
  await chooserA.accept([IMG])
  await sleep(1600)
  out.imageUpload = await page.evaluate(() => {
    const dataImgs = [...document.querySelectorAll('img')].filter((i) =>
      (i.getAttribute('src') || '').startsWith('data:image')
    )
    return { dataImages: dataImgs.length, heroPreviewIsData: dataImgs.length > 0 }
  })
  /* reopen picker -> Uploads chip should list it */
  await clickByText(page, 'change hero photo|change image')
  await sleep(700)
  out.uploadsChip = await page.evaluate(() => {
    const chip = [...document.querySelectorAll('button, [role=button], label')].find(
      (e) => e.textContent.trim() === 'Uploads'
    )
    if (!chip) return null
    chip.click()
    return true
  })
  await sleep(700)
  out.uploadsGrid = await page.evaluate(() => {
    const grid = [...document.querySelectorAll('button')].filter((b) =>
      (b.querySelector('img')?.getAttribute('src') || '').startsWith('data:image')
    )
    return { uploadThumbs: grid.length }
  })
  /* close the picker */
  await page.keyboard.press('Escape')
  await page.evaluate(() => document.body.click())
  await sleep(400)

  /* persistence across reload */
  await page.reload({ waitUntil: 'domcontentloaded' })
  await sleep(1700)
  out.imagePersist = await page.evaluate(
    () => [...document.querySelectorAll('img')].some((i) => (i.getAttribute('src') || '').startsWith('data:image'))
  )

  /* ---------- B. HERO VIDEO: start from a clean state ---------- */
  const removedFirst = await clickByText(page, '^Remove video$')
  if (removedFirst) await sleep(1000)
  out.hasVideoBlock = await page.evaluate(() =>
    [...document.querySelectorAll('h2, h3, h4, p, legend, span')].some(
      (e) => e.textContent.trim() === 'Hero video'
    )
  )
  await page.evaluate(() => {
    const inp = [...document.querySelectorAll('input')].find((i) =>
      (i.getAttribute('placeholder') || i.getAttribute('aria-label') || '').startsWith('https://')
    )
    if (!inp) return
    inp.scrollIntoView({ block: 'center' })
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set
    setter.call(inp, 'not-a-link')
    inp.dispatchEvent(new Event('input', { bubbles: true }))
  })
  await sleep(500)
  out.invalidClick = await page.evaluate(() => {
    const inp = [...document.querySelectorAll('input')].find((i) =>
      (i.getAttribute('placeholder') || i.getAttribute('aria-label') || '').startsWith('https://')
    )
    const btn = inp ? [...inp.parentElement.querySelectorAll('button')].find((b) => /apply/i.test(b.textContent)) : null
    if (!btn) return 'no-btn'
    if (btn.disabled) return 'disabled'
    btn.click()
    return 'clicked'
  })
  await sleep(600)
  out.invalidUrlError = await page.evaluate(() =>
    [...document.querySelectorAll('p')].some((e) => /valid link starting with http/i.test(e.textContent))
  )

  /* ---------- C. FILE UPLOAD of video (no video set yet) ---------- */
  const [chooserV] = await Promise.all([
    page.waitForFileChooser({ timeout: 10000 }),
    clickByText(page, '^Upload video$'),
  ])
  await chooserV.accept([VID])
  await sleep(3500)
  out.videoUpload = await page.evaluate(() => {
    const badge = [...document.querySelectorAll('*')].some(
      (e) => e.children.length === 0 && e.textContent.trim() === 'Uploaded file'
    )
    const panelVideo = [...document.querySelectorAll('video')].find(
      (v) => v.getBoundingClientRect().width > 0
    )
    return {
      badge,
      panelSrc: panelVideo ? (panelVideo.currentSrc || panelVideo.src || '').slice(0, 8) : null,
      removeBtn: [...document.querySelectorAll('button')].some(
        (b) => b.textContent.trim() === 'Remove video'
      ),
    }
  })
  /* persistence across reload (IndexedDB blob must resolve again) */
  await page.reload({ waitUntil: 'domcontentloaded' })
  await sleep(2200)
  out.videoPersist = await page.evaluate(() => {
    const hero = [...document.querySelectorAll('video')].find((v) => v.closest('.rs-hero'))
    const any = [...document.querySelectorAll('video')].find((v) => v.getBoundingClientRect().width > 0)
    return {
      heroAfterReload: Boolean(hero),
      heroSrcKind: hero ? (hero.currentSrc || hero.src || '').slice(0, 6) : null,
      anyVideo: Boolean(any),
      badge: [...document.querySelectorAll('*')].some(
        (e) => e.children.length === 0 && e.textContent.trim() === 'Uploaded file'
      ),
    }
  })

  /* ---------- E. REMOVE ---------- */
  await clickByText(page, '^Remove video$')
  await sleep(1200)
  out.afterRemove = await page.evaluate(() => ({
    videos: [...document.querySelectorAll('video')].filter((v) => v.getBoundingClientRect().width > 0)
      .length,
    urlInputBack: [...document.querySelectorAll('input')].some((i) =>
      (i.getAttribute('placeholder') || '').startsWith('https://')
    ),
    uploadBtnBack: [...document.querySelectorAll('button')].some(
      (b) => b.textContent.trim() === 'Upload video'
    ),
  }))

  /* ---------- E2. SAMPLE CLIP (left ON for the owner) ---------- */
  out.sampleClicked = await clickByText(page, 'use sample clip')
  await sleep(2200)
  out.sampleSet = await page.evaluate(() => {
    const heroVideo = [...document.querySelectorAll('video')].find((v) => v.closest('.rs-hero'))
    return {
      heroVideo: Boolean(heroVideo),
      heroSrcKind: heroVideo ? (heroVideo.currentSrc || heroVideo.src || '').slice(0, 6) : null,
      heroPoster: heroVideo ? (heroVideo.getAttribute('poster') || '').slice(0, 30) : null,
      pointerNone: heroVideo ? getComputedStyle(heroVideo).pointerEvents : null,
      removeBtn: [...document.querySelectorAll('button')].some(
        (b) => b.textContent.trim() === 'Remove video'
      ),
    }
  })

  /* ---------- F. PUBLISHED SITE: draft first, then publish, then play ---------- */
  await page.goto(`${BASE}/menu-demo`, { waitUntil: 'domcontentloaded' })
  await sleep(2500)
  out.publishedDraftState = await page.evaluate(() => ({
    videoBeforePublish: Boolean([...document.querySelectorAll('video')].find((x) => x.closest('.rs-hero'))),
    dirtyNotice: [...document.querySelectorAll('*')].some(
      (e) => e.children.length === 0 && /publish now/i.test(e.textContent)
    ) || [...document.querySelectorAll('button')].some((b) => /publish now|publish demo/i.test(b.textContent)),
  }))
  out.publishClicked = await clickByText(page, 'publish now|publish demo')
  await sleep(1500)
  await page.reload({ waitUntil: 'domcontentloaded' })
  await sleep(3000)
  out.published = await page.evaluate(() => {
    const v = [...document.querySelectorAll('video')].find((x) => x.closest('.rs-hero'))
    if (!v) return { video: false }
    return {
      video: true,
      srcKind: (v.currentSrc || v.src || '').slice(0, 6),
      muted: v.muted,
      loop: v.loop,
      autoplay: v.autoplay,
      playing: !v.paused && v.readyState >= 2,
      pointer: getComputedStyle(v).pointerEvents,
      poster: (v.getAttribute('poster') || '').slice(0, 24),
    }
  })

  /* ---------- G. EDITOR content panel has the block ---------- */
  await page.goto(`${BASE}/dashboard/editor`, { waitUntil: 'domcontentloaded' })
  await sleep(2000)
  out.editorBlock = await page.evaluate(() => ({
    heading: [...document.querySelectorAll('*')].some(
      (e) => e.children.length === 0 && e.textContent.trim() === 'Hero video'
    ),
    videoInPreview: Boolean([...document.querySelectorAll('video')].find((v) => v.closest('.rs-hero'))),
  }))
  /* regression: tapping the hero image still opens the image picker */
  await page.evaluate(() => {
    const media = document.querySelector('.rs-hero__media') || document.querySelector('.rs-hero__figure')
    if (media) media.scrollIntoView({ block: 'center' })
  })
  await sleep(400)
  if (out.editorBlock.videoInPreview) {
    /* video has pointer-events:none -> tap passes to the editable image below */
    const box = await page.evaluate(() => {
      const media = document.querySelector('.rs-hero__media') || document.querySelector('.rs-hero__figure')
      if (!media) return null
      const r = media.getBoundingClientRect()
      return r.width > 0 ? { x: r.x + r.width / 2, y: r.y + r.height / 2 } : null
    })
    if (box) {
      await page.mouse.click(box.x, box.y)
      await sleep(800)
      out.tapStillOpensPicker = await page.evaluate(
        () => document.querySelectorAll('input[placeholder*="earch"]').length > 0
      )
      await page.keyboard.press('Escape')
      await page.evaluate(() => document.body.click())
    }
  }

  /* ---------- H. ar @390 screenshot of the video block ---------- */
  await page.evaluate(() => localStorage.setItem('menucraft-lang', 'ar'))
  await page.goto(`${BASE}/dashboard/design`, { waitUntil: 'domcontentloaded' })
  await page.setViewport({ width: 390, height: 844 })
  await sleep(1800)
  out.mobile = await page.evaluate(() => {
    const h = [...document.querySelectorAll('h2, h3, h4, span')].find(
      (e) => e.textContent.trim() === 'فيديو الواجهة'
    )
    if (h) h.scrollIntoView({ block: 'start' })
    return { scroll: document.documentElement.scrollWidth, found: Boolean(h) }
  })
  await sleep(600)
  await page.screenshot({ path: `${process.env.TEMP}\\menucraft-shots\\hero-video-mobile-ar.png` })
  await page.setViewport({ width: 1440, height: 1000 })
  await sleep(700)

  out.errs = errs
  console.log(JSON.stringify(out, null, 1))
  await browser.close()
})()
