/* Dev-only: screenshots for the hero-video feature + dark admin picker check. */
const puppeteer = require('puppeteer-core')
const BASE = 'http://localhost:5173'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

async function clickByText(page, re, scope = 'button, a, [role=button]') {
  return page.evaluate(
    (rx, sel) => {
      const pattern = new RegExp(rx, 'i')
      const el = [...document.querySelectorAll(sel)].find((e) =>
        pattern.test((e.textContent || '').trim())
      )
      if (el) {
        el.click()
        return (el.textContent || '').trim().slice(0, 40)
      }
      return null
    },
    re,
    scope
  )
}

;(async () => {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
  })
  const page = await browser.newPage()
  const errs = []
  page.on('dialog', (d) => d.accept().catch(() => {}))
  page.on('console', (m) => {
    if (m.type() === 'error') errs.push(m.text().slice(0, 130))
  })
  const out = {}

  /* 1. design page — set sample clip + screenshot the block (desktop en) */
  await page.setViewport({ width: 1440, height: 940 })
  await page.goto(`${BASE}/dashboard/design`, { waitUntil: 'domcontentloaded' })
  await page.evaluate(() => localStorage.setItem('menucraft-lang', 'en'))
  await page.reload({ waitUntil: 'domcontentloaded' })
  await sleep(2200)
  out.sample = await clickByText(page, 'use sample clip')
  await sleep(2500)
  await page.evaluate(() => {
    const h = [...document.querySelectorAll('h2, h3, h4, span, p')].find(
      (e) => e.textContent.trim() === 'Hero video'
    )
    if (h) h.scrollIntoView({ block: 'start' })
  })
  await sleep(800)
  await page.screenshot({ path: `${process.env.TEMP}\\menucraft-shots\\hero-video-panel-desktop.png` })

  /* 2. published menu — publish the draft, wait for the video, screenshot */
  await page.goto(`${BASE}/menu-demo`, { waitUntil: 'domcontentloaded' })
  await sleep(2000)
  await clickByText(page, 'publish now|publish demo')
  await sleep(1800)
  await page.reload({ waitUntil: 'domcontentloaded' })
  for (let i = 0; i < 10; i++) {
    await sleep(1200)
    const st = await page.evaluate(() => {
      const v = [...document.querySelectorAll('video')].find((x) => x.closest('.rs-hero'))
      if (!v) return null
      if (v.readyState >= 2 && !v.paused) v.scrollIntoView({ block: 'center' })
      return { playing: !v.paused && v.readyState >= 2, ready: v.readyState }
    })
    if (st && st.playing) {
      out.heroVideoPlaying = true
      break
    }
    out.heroVideoPlaying = st
  }
  await sleep(900)
  await page.screenshot({ path: `${process.env.TEMP}\\menucraft-shots\\hero-video-desktop.png` })

  /* 3. admin Home tab — upload row on dark chrome (390) */
  await page.setViewport({ width: 390, height: 844 })
  await page.goto(`${BASE}/admin`, { waitUntil: 'domcontentloaded' })
  await sleep(1600)
  await clickByText(page, 'super admin')
  await sleep(1400)
  await clickByText(page, '^Home page$')
  await sleep(1400)
  out.adminHome = await page.evaluate(() => {
    const uploadBtn = [...document.querySelectorAll('button')].find(
      (b) => b.textContent.trim() === 'Upload image'
    )
    const uploadsChip = [...document.querySelectorAll('button, label, [role=button]')].find(
      (e) => e.textContent.trim() === 'Uploads'
    )
    return {
      uploadRow: Boolean(uploadBtn),
      uploadsChip: Boolean(uploadsChip),
      scroll: document.documentElement.scrollWidth,
    }
  })
  await page.screenshot({ path: `${process.env.TEMP}\\menucraft-shots\\admin-uploads-mobile.png` })

  out.errs = errs
  console.log(JSON.stringify(out, null, 1))
  await browser.close()
})()
