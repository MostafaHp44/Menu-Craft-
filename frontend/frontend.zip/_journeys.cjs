/* Dev-only: live journeys — language switcher, font pills, forgot password. */
const puppeteer = require('puppeteer-core')

const BASE = 'http://localhost:5173'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

async function clickByText(page, re, scope = 'button, a, [role=button]') {
  return page.evaluate(
    (rx, sel) => {
      const pattern = new RegExp(rx, 'i')
      const el = [...document.querySelectorAll(sel)].find((e) =>
        pattern.test(e.textContent || e.getAttribute('aria-label') || '')
      )
      if (el) {
        el.click()
        return (el.textContent || '').trim().slice(0, 50)
      }
      return null
    },
    re,
    scope
  )
}

;(async () => {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
  })
  const page = await browser.newPage()
  const errs = []
  page.on('dialog', (d) => d.accept().catch(() => {}))
  page.on('console', (m) => {
    if (m.type() === 'error') errs.push(m.text().slice(0, 140))
  })
  await page.setViewport({ width: 390, height: 844 })
  const out = {}

  /* ---------- A. language switcher on the public site (mobile drawer) ---------- */
  await page.goto(`${BASE}/`, { waitUntil: 'domcontentloaded' })
  await page.evaluate(() => localStorage.setItem('menucraft-lang', 'en'))
  await page.reload({ waitUntil: 'domcontentloaded' })
  await sleep(1200)
  out.hamburger = await clickByText(page, '^\\s*$|open menu|menu', 'header button[aria-label], header button')
  await sleep(400)
  out.switcherInDrawer = await page.evaluate(() => {
    const btns = [...document.querySelectorAll('button')].map((b) => b.textContent.trim())
    return { en: btns.includes('English') || btns.includes('EN'), ar: btns.includes('العربية') || btns.includes('ع'), ku: btns.includes('کوردی') || btns.includes('ک') }
  })
  await clickByText(page, '^العربية$|^ع$')
  await sleep(700)
  out.afterAr = await page.evaluate(() => ({
    dir: document.documentElement.dir,
    h1: (document.querySelector('h1')?.textContent || '').slice(0, 60),
  }))
  out.arIsArabic = /[\u0600-\u06FF]/.test(out.afterAr.h1)

  await page.evaluate(() => localStorage.setItem('menucraft-lang', 'ku'))
  await page.reload({ waitUntil: 'domcontentloaded' })
  await sleep(1200)
  out.afterKu = await page.evaluate(() => ({
    dir: document.documentElement.dir,
    h1: (document.querySelector('h1')?.textContent || '').slice(0, 60),
  }))

  /* ---------- B. font pills in the inline toolbar ---------- */
  await page.evaluate(() => localStorage.setItem('menucraft-lang', 'en'))
  await page.goto(`${BASE}/dashboard/editor`, { waitUntil: 'domcontentloaded' })
  await sleep(1800)
  /* on phones the site preview lives behind the "Preview" segmented tab */
  await page.evaluate(() => {
    const b = [...document.querySelectorAll('button')].find((x) => x.textContent.trim() === 'Preview')
    b && b.click()
  })
  await sleep(900)
  const target = await page.evaluate(() => {
    const el = [...document.querySelectorAll('[contenteditable=true], [contenteditable="true"]')].find((e) => {
      const r = e.getBoundingClientRect()
      return r.width > 0 && r.height > 0 && e.textContent.trim().length > 4
    })
    if (!el) return null
    const r = el.getBoundingClientRect()
    return { x: r.x + r.width / 2, y: r.y + r.height / 2, text: el.textContent.slice(0, 30) }
  })
  out.editTarget = target
  if (target) await page.mouse.click(target.x, target.y)
  await sleep(700)
  out.toolbarFontRow = await page.evaluate(() => {
    const btns = [...document.querySelectorAll('button')]
    return {
      lora: btns.some((b) => b.textContent.trim() === 'Lora'),
      default: btns.some((b) => b.textContent.trim() === 'Default'),
      count: document.querySelectorAll('button').length,
    }
  })
  out.fontApplied = await page.evaluate(() => {
    const btn = [...document.querySelectorAll('button')].find((b) => b.textContent.trim() === 'Lora')
    if (!btn) return 'NO-PILL'
    btn.scrollIntoView({ block: 'nearest', inline: 'center' })
    btn.click()
    return 'CLICKED'
  })
  await sleep(500)
  out.fontApplied = await page.evaluate((prev) => {
    const styled = [...document.querySelectorAll('h1, h2, h3, p, span, a, div')].find(
      (e) => (e.style?.fontFamily || '').length > 0
    )
    return {
      click: prev,
      found: styled ? styled.style.fontFamily.slice(0, 70) : null,
      hasLora: Boolean(styled && styled.style.fontFamily.includes('Lora')),
    }
  }, out.fontApplied)
  out.fontCleared = await page.evaluate(() => {
    const btn = [...document.querySelectorAll('button')].find((b) => b.textContent.trim() === 'Default')
    if (!btn) return 'NO-DEFAULT'
    btn.scrollIntoView({ block: 'nearest', inline: 'center' })
    btn.click()
    return 'CLICKED'
  })
  await sleep(500)
  out.fontCleared = await page.evaluate((prev) => {
    const styled = [...document.querySelectorAll('h1, h2, h3, p, span, a, div')].find(
      (e) => (e.style?.fontFamily || '').length > 0
    )
    return { click: prev, stillStyled: styled ? styled.style.fontFamily.slice(0, 50) : null }
  }, out.fontCleared)

  /* ---------- C. social buttons + forgot password ---------- */
  await page.goto(`${BASE}/signin?mode=signin`, { waitUntil: 'domcontentloaded' })
  await sleep(1200)
  out.socialButtons = await page.evaluate(() => {
    const txt = document.body.textContent
    return { google: /continue with google/i.test(txt), facebook: /continue with facebook/i.test(txt) }
  })
  out.forgotLink = await clickByText(page, 'forgot password')
  await sleep(500)
  await page.evaluate(() => {
    const input = document.querySelector('input[type=email], input[name=email], input')
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set
    setter.call(input, 'owner@bella.demo')
    input.dispatchEvent(new Event('input', { bubbles: true }))
  })
  await sleep(300)
  out.sendReset = await clickByText(page, 'send.*reset|reset link')
  await sleep(700)
  out.sentState = await page.evaluate(() => /check|sent|inbox/i.test(document.body.textContent))
  out.openReset = await clickByText(page, 'open.*reset|demo.*link')
  await sleep(700)
  out.resetForm = await page.evaluate(() => document.querySelectorAll('input[type=password]').length)
  await page.evaluate(() => {
    const inputs = [...document.querySelectorAll('input[type=password]')]
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set
    inputs.forEach((i) => {
      setter.call(i, 'demo1234')
      i.dispatchEvent(new Event('input', { bubbles: true }))
    })
  })
  await sleep(300)
  out.updatePassword = await clickByText(page, 'update|save|set|reset.*password|confirm')
  await sleep(1600)
  out.afterReset = await page.evaluate(() => ({
    path: location.pathname,
    signedIn: !/sign in|create account/i.test(document.body.textContent.slice(0, 400)),
  }))

  out.errs = errs
  console.log(JSON.stringify(out, null, 1))
  await browser.close()
})()
