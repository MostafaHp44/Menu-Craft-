/* Dev-only: precise ImagePicker checks — scoped counts, clear, URL error, hero change. */
const puppeteer = require('puppeteer-core')
const BASE = 'http://localhost:5173'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

;(async () => {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
  })
  const page = await browser.newPage()
  const errs = []
  page.on('dialog', (d) => d.accept().catch(() => {}))
  page.on('console', (m) => {
    if (m.type() === 'error') errs.push(m.text().slice(0, 140))
  })
  await page.setViewport({ width: 390, height: 844 })
  const out = {}

  await page.goto(`${BASE}/dashboard/design`, { waitUntil: 'domcontentloaded' })
  await page.evaluate(() => localStorage.setItem('menucraft-lang', 'en'))
  await page.reload({ waitUntil: 'domcontentloaded' })
  await sleep(1800)
  await page.evaluate(() => {
    const b = [...document.querySelectorAll('button')].find((x) => /change hero photo/i.test(x.textContent))
    b && b.click()
  })
  await sleep(600)

  /* locate the picker root: ancestor of the search input that holds the thumbs */
  const pickerInfo = await page.evaluate(() => {
    const search = [...document.querySelectorAll('input')].find((i) => /search/i.test(i.placeholder))
    if (!search) return null
    let root = search
    for (let i = 0; i < 8 && root; i++) {
      root = root.parentElement
      if (root && root.querySelectorAll('img[src*="food-"]').length >= 10) break
    }
    if (!root) return null
    const urlInput = [...root.querySelectorAll('input')].find(
      (i) => !/search/i.test(i.placeholder) && i.type !== 'hidden'
    )
    const clearBtn = [...root.querySelectorAll('button')].find((b) =>
      /clear/i.test(b.textContent + ' ' + (b.getAttribute('aria-label') || ''))
    )
    return {
      thumbs: root.querySelectorAll('img[src*="food-"]').length,
      urlPlaceholder: urlInput ? urlInput.placeholder : null,
      clearBtn: clearBtn ? { text: clearBtn.textContent.trim(), aria: clearBtn.getAttribute('aria-label') } : null,
      rootId: root.id || root.className.slice(0, 40),
    }
  })
  out.picker = pickerInfo

  /* HERO src before/after — the design page hero preview image */
  out.heroBefore = await page.evaluate(() => {
    const img = [...document.querySelectorAll('img')].find((i) => /hero/i.test(i.alt || ''))
    return img ? img.getAttribute('src') : '?'
  })

  /* scoped: count thumbs in picker after pizza search */
  const setInPicker = async (value) => {
    await page.evaluate((val) => {
      const search = [...document.querySelectorAll('input')].find((i) => /search/i.test(i.placeholder))
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set
      setter.call(search, val)
      search.dispatchEvent(new Event('input', { bubbles: true }))
    }, value)
    await sleep(400)
    return page.evaluate(() => {
      const search = [...document.querySelectorAll('input')].find((i) => /search/i.test(i.placeholder))
      let root = search
      for (let i = 0; i < 8 && root; i++) root = root.parentElement
      return root ? root.querySelectorAll('img[src*="food-"]').length : -1
    })
  }
  out.pizzaCount = await setInPicker('pizza')
  out.emptyMsg = await page.evaluate(() =>
    document.body.textContent.match(/No images match[^.]{0,30}/)?.[0] ?? null
  )
  out.pastaNoClear = await page.evaluate(() => {
    const b = [...document.querySelectorAll('button')].find((x) => x.textContent.trim() === 'Pasta')
    if (!b) return null
    b.click()
    return 'clicked'
  })
  await sleep(400)
  out.comboCount = await page.evaluate(() => {
    const search = [...document.querySelectorAll('input')].find((i) => /search/i.test(i.placeholder))
    let root = search
    for (let i = 0; i < 8 && root; i++) root = root.parentElement
    return root ? root.querySelectorAll('img[src*="food-"]').length : -1
  })

  /* clear search via the clear control (button or input X) */
  out.clearClick = await page.evaluate(() => {
    const search = [...document.querySelectorAll('input')].find((i) => /search/i.test(i.placeholder))
    let root = search
    for (let i = 0; i < 8 && root; i++) root = root.parentElement
    const clearBtn = root && [...root.querySelectorAll('button')].find((b) => /clear/i.test((b.getAttribute('aria-label') || '') + b.textContent))
    if (clearBtn) {
      clearBtn.click()
      return { via: 'button', label: clearBtn.getAttribute('aria-label') || clearBtn.textContent.trim() }
    }
    /* fall back: clear input manually */
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set
    setter.call(search, '')
    search.dispatchEvent(new Event('input', { bubbles: true }))
    return { via: 'input' }
  })
  await sleep(400)
  out.afterClear = await page.evaluate(() => {
    const search = [...document.querySelectorAll('input')].find((i) => /search/i.test(i.placeholder))
    let root = search
    for (let i = 0; i < 8 && root; i++) root = root.parentElement
    return {
      query: search.value,
      thumbs: root ? root.querySelectorAll('img[src*="food-"]').length : -1,
    }
  })

  /* click first VISIBLE PICKER thumb -> hero must change */
  out.heroAfter = await page.evaluate(() => {
    const search = [...document.querySelectorAll('input')].find((i) => /search/i.test(i.placeholder))
    let root = search
    for (let i = 0; i < 8 && root; i++) root = root.parentElement
    const thumb = root && [...root.querySelectorAll('button')].find((b) => b.querySelector('img[src*="food-"]'))
    if (!thumb) return null
    thumb.click()
    const img = thumb.querySelector('img')
    return img.getAttribute('src')
  })
  await sleep(600)
  out.heroNow = await page.evaluate(() => {
    const img = [...document.querySelectorAll('img')].find((i) => /hero/i.test(i.alt || ''))
    const pressed = [...document.querySelectorAll('button[aria-pressed=true]')].map(
      (b) => b.querySelector('img')?.getAttribute('src') || b.textContent.trim().slice(0, 20)
    )
    return { hero: img ? img.getAttribute('src') : '?', pressed }
  })

  /* URL: bad then good */
  await page.evaluate(() => {
    const search = [...document.querySelectorAll('input')].find((i) => /search/i.test(i.placeholder))
    let root = search
    for (let i = 0; i < 8 && root; i++) root = root.parentElement
    const url = root && [...root.querySelectorAll('input')].find((i) => i !== search)
    if (url) {
      const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set
      setter.call(url, 'banana')
      url.dispatchEvent(new Event('input', { bubbles: true }))
      url.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }))
      const apply = [...root.querySelectorAll('button')].find((b) => /^apply$/i.test(b.textContent.trim()))
      apply && apply.click()
    }
    window.__urlFound = Boolean(url)
  })
  await sleep(500)
  out.urlFound = await page.evaluate(() => window.__urlFound)
  out.urlError = await page.evaluate(() => {
    const search = [...document.querySelectorAll('input')].find((i) => /search/i.test(i.placeholder))
    let root = search
    for (let i = 0; i < 8 && root; i++) root = root.parentElement
    const texts = root ? root.textContent : ''
    const m = texts.match(/(valid|link|url|https)[^.]{0,50}/i)
    return m ? m[0].slice(0, 80) : null
  })

  out.errs = errs
  console.log(JSON.stringify(out, null, 1))
  await browser.close()
})()
