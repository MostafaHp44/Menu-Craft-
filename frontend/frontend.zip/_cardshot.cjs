/* Dev-only: close-ups of the admin-added template card (seeded via store). */
const fs = require('fs')
const os = require('os')
const path = require('path')
const puppeteer = require('puppeteer-core')

const DIR = path.join(os.tmpdir(), 'menucraft-shots')
const BASE = 'http://localhost:5173'
const NAME = 'قائمة الصيف'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

;(async () => {
  fs.mkdirSync(DIR, { recursive: true })
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
  })
  const page = await browser.newPage()
  const errs = []
  page.on('dialog', (d) => d.accept().catch(() => {}))
  page.on('console', (m) => {
    if (m.type() === 'error') errs.push(m.text().slice(0, 140))
  })
  await page.setViewport({ width: 1440, height: 900 })

  /* pick a real stock id, then seed a custom template into the store */
  await page.goto(`${BASE}/templates`, { waitUntil: 'domcontentloaded' })
  await sleep(1200)
  const baseId = await page.evaluate(() => {
    const href = document.querySelector('article a[href^="/templates/"]')?.getAttribute('href')
    return href ? href.replace('/templates/', '') : null
  })
  await page.evaluate(
    (base, name) => {
      localStorage.setItem(
        'menucraft-platform-v1',
        JSON.stringify({
          state: { customTemplates: [{ baseTemplateId: base, name, category: 'Fine Dining' }] },
          version: 1,
        })
      )
    },
    baseId,
    NAME
  )
  await page.reload({ waitUntil: 'domcontentloaded' })
  await sleep(1200)

  /* gallery close-up of the New card */
  await page.evaluate((name) => {
    const card = [...document.querySelectorAll('article')].find((a) =>
      a.textContent.includes(name)
    )
    card && card.scrollIntoView({ block: 'center' })
  }, NAME)
  await sleep(500)
  await page.screenshot({ path: path.join(DIR, 'x-gallery-new-card.png') })

  /* dashboard picker close-up */
  await page.goto(`${BASE}/dashboard/templates`, { waitUntil: 'domcontentloaded' })
  await sleep(1400)
  await page.evaluate((name) => {
    const card = [...document.querySelectorAll('article')].find((a) =>
      a.textContent.includes(name)
    )
    card && card.scrollIntoView({ block: 'center' })
  }, NAME)
  await sleep(500)
  await page.screenshot({ path: path.join(DIR, 'x-dashboard-new-card.png') })

  /* mobile gallery with the custom card */
  await page.setViewport({ width: 390, height: 844 })
  await page.goto(`${BASE}/templates`, { waitUntil: 'domcontentloaded' })
  await sleep(1200)
  await page.evaluate((name) => {
    const card = [...document.querySelectorAll('article')].find((a) =>
      a.textContent.includes(name)
    )
    card && card.scrollIntoView({ block: 'center' })
  }, NAME)
  await sleep(500)
  const mobile = await page.evaluate(() => ({
    scroll: document.documentElement.scrollWidth,
    vw: document.documentElement.clientWidth,
  }))
  await page.screenshot({ path: path.join(DIR, 'x-gallery-new-card-mobile.png') })

  console.log(JSON.stringify({ baseId, mobile, errs }, null, 1))
  await browser.close()
})()
