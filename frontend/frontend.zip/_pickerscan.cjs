/* Dev-only: enumerate every ImagePicker on the design page (hero vs gallery). */
const puppeteer = require('puppeteer-core')
const BASE = 'http://localhost:5173'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

;(async () => {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
  })
  const page = await browser.newPage()
  const errs = []
  page.on('console', (m) => {
    if (m.type() === 'error') errs.push(m.text().slice(0, 100))
  })
  await page.setViewport({ width: 390, height: 900 })
  await page.goto(`${BASE}/dashboard/design`, { waitUntil: 'domcontentloaded' })
  await page.evaluate(() => localStorage.setItem('menucraft-lang', 'en'))
  await page.reload({ waitUntil: 'domcontentloaded' })
  await sleep(1800)

  const scan = async (label) => {
    const res = await page.evaluate(() => {
      const searches = [...document.querySelectorAll('input')].filter((i) => /search/i.test(i.placeholder || ''))
      const pickers = searches.map((search, idx) => {
        let root = search
        for (let i = 0; i < 8 && root; i++) {
          root = root.parentElement
          if (root && root.querySelectorAll('img[src*="food-"]').length >= 10) break
        }
        if (!root) return { idx, root: null }
        const pressed = [...root.querySelectorAll('button[aria-pressed=true]')].map(
          (b) => b.querySelector('img')?.getAttribute('src')?.replace('/images/food/', '') || 'chip:' + b.textContent.trim().slice(0, 10)
        )
        const rect = root.getBoundingClientRect()
        const heading = root.closest('div[class]')
          ? (root.parentElement?.parentElement?.textContent || '').slice(0, 45)
          : ''
        return {
          idx,
          y: Math.round(rect.y),
          thumbs: root.querySelectorAll('img[src*="food-"]').length,
          pressed,
          head: heading.replace(/\s+/g, ' '),
        }
      })
      const heroImg = [...document.querySelectorAll('img')].find((i) => /hero/i.test(i.alt || ''))
      const heroToggle = [...document.querySelectorAll('button')].find((b) => /change hero photo/i.test(b.textContent))
      return {
        searches: searches.length,
        pickers,
        hero: heroImg ? heroImg.getAttribute('src').replace('/images/food/', '') : '?',
        heroToggleVisible: heroToggle ? heroToggle.getBoundingClientRect().height > 0 : false,
      }
    })
    console.log(`--- ${label} ---`)
    console.log(JSON.stringify(res, null, 1))
    return res
  }

  const before = await scan('BEFORE opening hero')

  await page.evaluate(() => {
    const b = [...document.querySelectorAll('button')].find((x) => /change hero photo/i.test(x.textContent))
    b && b.click()
  })
  await sleep(700)
  const after = await scan('AFTER opening hero')

  /* click a thumb in picker idx0 (should be hero if hero is first) */
  const clicked = await page.evaluate(() => {
    const searches = [...document.querySelectorAll('input')].filter((i) => /search/i.test(i.placeholder || ''))
    const search = searches[0]
    let root = search
    for (let i = 0; i < 8 && root; i++) {
      root = root.parentElement
      if (root && root.querySelectorAll('img[src*="food-"]').length >= 10) break
    }
    const thumbs = [...root.querySelectorAll('button')].filter((b) => b.querySelector('img[src*="food-"]'))
    const t = thumbs[7]
    if (!t) return null
    const src = t.querySelector('img').getAttribute('src').replace('/images/food/', '')
    t.click()
    return src
  })
  await sleep(700)
  const final = await scan(`AFTER clicking picker-0 thumb ${clicked}`)
  console.log('errs', errs)
  await browser.close()
})()
