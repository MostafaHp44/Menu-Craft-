/* Dev-only: verify home-content v1 → v2 migration preserves edits. */
const puppeteer = require('puppeteer-core')

const BASE = 'http://localhost:5173'
const KEY = 'menucraft-home-v1'
const MARK = 'MIGRATED-TEST-42'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

;(async () => {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
  })
  const page = await browser.newPage()
  const errs = []
  page.on('console', (m) => {
    if (m.type() === 'error') errs.push(m.text().slice(0, 140))
  })
  await page.setViewport({ width: 1440, height: 900 })
  const out = {}

  /* seed a LEGACY v1 payload with one edited English field */
  await page.goto(`${BASE}/`, { waitUntil: 'domcontentloaded' })
  await sleep(1000)
  await page.evaluate(
    (key, mark) => {
      localStorage.setItem(
        key,
        JSON.stringify({ state: { content: { hero: { title: mark } } }, version: 1 })
      )
      localStorage.setItem('menucraft-lang', 'en')
    },
    KEY,
    MARK
  )
  await page.reload({ waitUntil: 'domcontentloaded' })
  await sleep(1200)

  out.enHeading = await page.evaluate(() => document.querySelector('h1')?.textContent ?? '?')
  out.storageAfterLoad = await page.evaluate((key) => {
    const raw = JSON.parse(localStorage.getItem(key) || '{}')
    return {
      version: raw.version,
      hasEn: Boolean(raw.state?.content?.en),
      enTitle: raw.state?.content?.en?.hero?.title,
      hasAr: Boolean(raw.state?.content?.ar),
      hasKu: Boolean(raw.state?.content?.ku),
    }
  }, KEY)

  /* switch to Arabic — edited English must NOT leak, Arabic seed must show */
  await page.evaluate(() => localStorage.setItem('menucraft-lang', 'ar'))
  await page.reload({ waitUntil: 'domcontentloaded' })
  await sleep(1200)
  out.arHeading = await page.evaluate(() => document.querySelector('h1')?.textContent ?? '?')
  out.arIsArabic = /[\u0600-\u06FF]/.test(out.arHeading)
  out.arHasMark = out.arHeading.includes(MARK)

  /* back to English — edit still there after two reloads */
  await page.evaluate(() => localStorage.setItem('menucraft-lang', 'en'))
  await page.reload({ waitUntil: 'domcontentloaded' })
  await sleep(1200)
  out.enHeadingAgain = await page.evaluate(() => document.querySelector('h1')?.textContent ?? '?')

  out.errs = errs
  console.log(JSON.stringify(out, null, 1))
  await browser.close()
})()
