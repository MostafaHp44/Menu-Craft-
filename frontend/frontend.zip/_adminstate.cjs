﻿const puppeteer = require('puppeteer-core')
const BASE = 'http://localhost:5173'
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
;(async () => {
  const browser = await puppeteer.launch({
    executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    headless: 'new',
  })
  const page = await browser.newPage()
  const errs = []
  page.on('console', (m) => { if (m.type() === 'error') errs.push(m.text().slice(0, 100)) })
  await page.setViewport({ width: 1440, height: 900 })
  await page.goto(`${BASE}/admin`, { waitUntil: 'domcontentloaded' })
  await page.evaluate(() => localStorage.setItem('menucraft-lang', 'en'))
  await page.reload({ waitUntil: 'domcontentloaded' })
  await sleep(1600)
  const state = await page.evaluate(() => ({
    path: location.pathname,
    h1: document.querySelector('h1')?.textContent?.slice(0, 60) || null,
    gate: /platform access|required|sign in/i.test(document.body.textContent.slice(0, 600)),
    buttons: [...new Set([...document.querySelectorAll('button')].map((b) => b.textContent.trim()).filter((t) => t && t.length < 30))].slice(0, 20),
  }))
  await page.screenshot({ path: `${process.env.TEMP}\\menucraft-shots\\admin-fresh.png` })
  console.log(JSON.stringify({ state, errs }, null, 1))
  await browser.close()
})()
